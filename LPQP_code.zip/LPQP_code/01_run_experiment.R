lpqp_script_dir <- function() {
  ff <- sys.frames()
  of <- unlist(lapply(ff, function(x) if (!is.null(x$ofile)) x$ofile else NULL))
  if (length(of)) return(dirname(normalizePath(tail(of,1),mustWork=FALSE)))
  ca <- commandArgs(FALSE); arg <- ca[startsWith(ca,"--file=")]
  if (length(arg)) return(dirname(normalizePath(sub("--file=","",arg[1]),mustWork=FALSE)))
  getwd()
}
LPQP_BASE_DIR <- lpqp_script_dir()
LPQP_CODE_VERSION <- "3.0.0"
LPQP_SOURCE_FILE <- local({
  z <- Filter(Negate(is.null),lapply(sys.frames(),function(f) f$ofile))
  if(length(z)) normalizePath(tail(z,1)[[1]],mustWork=TRUE) else
    file.path(LPQP_BASE_DIR,"01_run_experiment.R")
})

lpqp_config <- function(mode="full",task="main") {
  stopifnot(mode %in% c("pilot","full","smoke"))
  cfg <- list(MODE=mode,RUN_SCOPE=task,
       N=switch(mode,smoke=128L,pilot=c(400L,800L),full=c(400L,800L,1600L)),
       REPLICATIONS=switch(mode,smoke=4L,pilot=100L,full=1000L),
       BOOT_B=switch(mode,smoke=99L,pilot=399L,full=999L),
       CORES=8L,SEED=20260924L,LEVEL=0.05,
       P_GRID=c(1,1.15,1.25,1.35,1.5,1.75,2),
       RHO=if(mode=="full") c(0,0.6,0.85) else c(0,0.85),
       EPSILON=c(0,0.01,0.03,0.05),OUTLIER_SCALE=20,
       AMPLITUDE_NEGATIVE=0.1,AMPLITUDE_STRENGTH=0.8,
       LAG_MAX=8L,STATISTICS=c("Energy","CvM"),CALIBRATION="permutation",
       BLOCK_MULTIPLIER=1.5,BLOCK_EXPONENT=1/3,
       INCLUDE_ORACLE=FALSE,CHUNK_SIZE=25L,RESUME=TRUE,
       OUTPUT_DIR=file.path(LPQP_BASE_DIR,"outputs",if(mode=="full") "simulation" else paste0("simulation_",mode)),
       EMISSION=list(a=0.002,b=1,c=10,jitter=0.15,
                     interior_positive_prob=0.8,
                     central_prob=0.20,central_scale=0.0005))
  stopifnot(task %in% c("null_check","main"))
  cfg$MAIN_RESULTS_DIR <- NULL
  if(task=="null_check") {
    cfg$N <- 400L; cfg$RHO <- 0; cfg$EPSILON <- 0.03
    cfg$REPLICATIONS <- switch(mode,smoke=4L,pilot=100L,full=10000L)
    cfg$BOOT_B <- if(mode=="smoke") 99L else 999L
    cfg$SEED <- 20260925L
    cfg$OUTPUT_DIR <- file.path(LPQP_BASE_DIR,"outputs",if(mode=="full") "null_check" else paste0("null_check_",mode))
  }
  cfg
}

lpqp_models <- function(cfg) {
  e <- cfg$EMISSION
  e$epsilon <- 0; e$outlier_scale <- cfg$OUTLIER_SCALE; e$strength <- 1
  first <- e
  first$positive_prob <- 0.5
  first$negative_large_prob <- (e$b-e$a)/(e$c-e$a)
  second <- e
  second$positive_prob <- e$interior_positive_prob
  second$c <- e$b*(second$positive_prob/(1-second$positive_prob))^2
  second$negative_large_prob <- 1
  third <- e
  third$a <- cfg$AMPLITUDE_NEGATIVE
  third$positive_prob <- 0.5; third$negative_large_prob <- 0
  third$strength <- cfg$AMPLITUDE_STRENGTH
  list(endpoints_blind=first,amplitude_only=third,interior_blind=second)
}

lpqp_jitter_moment <- function(q,delta) {
  if(abs(q)<1e-14 || abs(q-1)<1e-14) return(1)
  integrate(function(t) (1+delta*t)^q*0.75*(1-t*t),-1,1,
            rel.tol=1e-11,abs.tol=1e-12)$value
}

lpqp_population <- function(p,model) {
  r <- p-1; w <- model$negative_large_prob; z <- model$central_prob
  v1 <- lpqp_jitter_moment(r,model$jitter)
  v2 <- lpqp_jitter_moment(2*r,model$jitter)
  pos <- model$positive_prob; eps <- model$epsilon
  m0 <- (1-z)*v1*(pos*model$b^r-(1-pos)*((1-w)*model$a^r+w*model$c^r))
  v0 <- z*model$central_scale^(2*r)*3/((2*r+1)*(2*r+3)) +
    (1-z)*v2*(pos*model$b^(2*r)+(1-pos)*((1-w)*model$a^(2*r)+w*model$c^(2*r)))
  m <- (1-eps)*model$strength*m0
  v <- (1-eps)*v0+eps*model$outlier_scale^(2*r)*v2
  data.frame(p=p,conditional_mean=m,variance=v,chi=m*m/v)
}

lpqp_spectrum <- function(omega,rho,chi,dynamics) {
  w0 <- if(dynamics=="cycle4") pi/2 else 0
  pois <- function(x) (1-rho*rho)/(1-2*rho*cos(x)+rho*rho)
  1-chi+chi/2*(pois(omega-w0)+pois(omega+w0))
}
lpqp_shape <- function(lambda,rho,chi,dynamics) {
  w0 <- if(dynamics=="cycle4") pi/2 else 0
  aa <- function(x) atan2(rho*sin(x),1-rho*cos(x))
  lambda/pi+chi/pi*(aa(lambda+w0)+aa(lambda-w0))
}
lpqp_acf <- function(lag,rho,chi,dynamics) {
  w0 <- if(dynamics=="cycle4") pi/2 else 0
  ifelse(lag==0,1,chi*rho^abs(lag)*cos(lag*w0))
}

lpqp_generate <- function(n,rho,dynamics,model) {
  if(dynamics=="cycle4") {
    state <- integer(n); state[1] <- sample.int(4L,1L)-1L
    rotate <- runif(n)<rho; reset <- sample.int(4L,n,replace=TRUE)-1L
    for(t in 2:n) state[t] <- if(rotate[t]) (state[t-1]+1L) %% 4L else reset[t]
    ss <- c(1,1,-1,-1)[state+1L]
  } else {
    first <- sample(c(-1,1),1L)
    ss <- first*c(1,cumprod(ifelse(runif(n-1L)<(1-rho)/2,-1,1)))
  }
  center <- runif(n)<model$central_prob; u <- runif(n)
  w <- model$negative_large_prob; pos <- model$positive_prob
  atom <- ifelse(u<pos,model$b,ifelse(u<1-(1-pos)*w,-model$a,-model$c))
  xx <- atom*(1+model$jitter*(2*rbeta(n,2,2)-1))
  xx[center] <- model$central_scale*(2*rbeta(sum(center),2,2)-1)

  if(model$strength<1) xx <- xx*ifelse(runif(n)<(1+model$strength)/2,1,-1)
  yy <- ss*xx

  bad <- runif(n)<model$epsilon
  if(any(bad)) yy[bad] <- sample(c(-1,1),sum(bad),replace=TRUE)*
    model$outlier_scale*(1+model$jitter*(2*rbeta(sum(bad),2,2)-1))
  list(y=yy,state_sign=ss,contaminated=bad)
}

lpqp_score <- function(u,p) {
  if(abs(p-1)<1e-12) return(sign(u))
  sign(u)*abs(u)^(p-1)
}
lpqp_location <- function(y,p) {
  if(abs(p-1)<1e-12) return(median(y))
  if(abs(p-2)<1e-12) return(mean(y))
  uniroot(function(m) mean(lpqp_score(y-m,p)),range(y),tol=1e-10,maxiter=200L)$root
}
lpqp_score_matrix <- function(y,pgrid,estimator="fitted") {
  mu <- if(estimator=="oracle") rep(0,length(pgrid)) else
    vapply(pgrid,function(p) lpqp_location(y,p),numeric(1))
  ss <- vapply(seq_along(pgrid),function(j) lpqp_score(y-mu[j],pgrid[j]),numeric(length(y)))
  list(scores=sweep(ss,2,colMeans(ss),"-"),location=mu)
}
lpqp_empirical_shape <- function(s,lambda) {
  n <- length(s); q <- floor(n/2)
  ii <- Mod(fft(s-mean(s))[2:(q+1L)])^2/n
  if(n %% 2L==0L) ii[q] <- ii[q]/2
  if(!is.finite(sum(ii)) || sum(ii)<=0) stop("Zero spectral mass.")
  cc <- c(0,cumsum(ii)/sum(ii))
  cc[findInterval(lambda,2*pi*(1:q)/n)+1L]
}

lpqp_permutation_statistics <- function(scores,cfg,index=NULL) {
  n <- nrow(scores); np <- ncol(scores); kk <- cfg$LAG_MAX; m <- n-kk
  vv <- colMeans(scores^2)
  if(any(!is.finite(vv) | vv<=0)) stop("Degenerate score variance.")
  sc <- sweep(scores,2,sqrt(vv),"/")
  nb <- cfg$BOOT_B+1L
  if(is.null(index)) index <- cbind(seq_len(n),replicate(cfg$BOOT_B,sample.int(n)))
  stopifnot(nrow(index)==n,ncol(index)==nb)
  current <- index[(kk+1L):n,,drop=FALSE]
  energy <- cvm <- matrix(0,nb,np)
  for(h in seq_len(kk)) {
    past <- index[(kk+1L-h):(n-h),,drop=FALSE]
    for(j in seq_len(np)) {
      ac <- colMeans(matrix(sc[,j][current]*sc[,j][past],m,nb))
      contribution <- m*ac^2
      energy[,j] <- energy[,j]+contribution
      cvm[,j] <- cvm[,j]+contribution/h^2
    }
  }
  list(Energy=energy,CvM=cvm)
}

lpqp_rank_statistics <- function(values,cfg) {
  nb <- nrow(values[[1]])
  ep <- which(cfg$P_GRID %in% c(1,2))
  out <- lapply(cfg$STATISTICS,function(stat) {
    vals <- values[[stat]]

    pp <- apply(vals,2,function(x) rank(-x,ties.method="max")/nb)
    epmin <- apply(pp[,ep,drop=FALSE],1,min)
    allmin <- apply(pp,1,min)
    pv <- c(pp[1,],mean(epmin<=epmin[1]),mean(allmin<=allmin[1]))
    data.frame(test=stat,method=c(sprintf("p=%.2f",cfg$P_GRID),"Endpoint-union","Adaptive-p"),
      p=c(cfg$P_GRID,NA_real_,NA_real_),
      statistic=c(vals[1,],-log(epmin[1]),-log(allmin[1])),pvalue=pv,
      selected_p=c(cfg$P_GRID,cfg$P_GRID[ep[which.min(pp[1,ep])]],cfg$P_GRID[which.min(pp[1,])]),
      block_length=0L,covariance_rank=NA_integer_)
  })
  do.call(rbind,out)
}

lpqp_permutation_test <- function(scores,cfg) {
  lpqp_rank_statistics(lpqp_permutation_statistics(scores,cfg),cfg)
}

lpqp_test <- function(scores,cfg) {
  if(cfg$CALIBRATION=="permutation") return(lpqp_permutation_test(scores,cfg))
  n <- nrow(scores); np <- ncol(scores); kk <- cfg$LAG_MAX; m <- n-kk
  tt <- (kk+1L):n; vv <- colMeans(scores^2)
  if(any(!is.finite(vv) | vv<=0)) stop("Degenerate score variance.")
  zz <- matrix(0,m,kk*np)
  for(j in seq_len(np)) for(h in seq_len(kk))
    zz[,(j-1L)*kk+h] <- scores[tt,j]*scores[tt-h,j]/vv[j]
  means <- colMeans(zz)
  if(cfg$CALIBRATION=="model_null") {
    cc <- (crossprod(scores)/n)/sqrt(outer(vv,vv)); diag(cc) <- 1
    sigma <- cc*cc; ell <- 0L
  } else {
    zc <- sweep(zz,2,means,"-")
    ell <- min(max(2L,floor(cfg$BLOCK_MULTIPLIER*m^cfg$BLOCK_EXPONENT)),floor(m/4))
    cs <- rbind(0,apply(zc,2,cumsum)); starts <- seq_len(m-ell+1L)
    bs <- (cs[starts+ell,,drop=FALSE]-cs[starts,,drop=FALSE])/sqrt(ell)
    sigma <- crossprod(bs)/nrow(bs)
  }
  eg <- eigen((sigma+t(sigma))/2,symmetric=TRUE)
  if(min(eg$values) < -max(1,max(eg$values))*1e-10) stop("Invalid bootstrap covariance.")
  keep <- eg$values>max(eg$values)*1e-12
  if(!any(keep)) stop("Degenerate bootstrap covariance.")
  root <- sweep(eg$vectors[,keep,drop=FALSE],2,sqrt(eg$values[keep]),"*")
  if(cfg$CALIBRATION=="model_null") {

    aa <- root %*% matrix(rnorm(sum(keep)*kk*cfg$BOOT_B),sum(keep),kk*cfg$BOOT_B)
    gg <- matrix(aperm(array(aa,c(np,kk,cfg$BOOT_B)),c(2,1,3)),kk*np,cfg$BOOT_B)
    rank <- sum(keep)*kk
  } else {
    gg <- root %*% matrix(rnorm(sum(keep)*cfg$BOOT_B),sum(keep),cfg$BOOT_B)
    rank <- sum(keep)
  }
  endpoint <- which(cfg$P_GRID %in% c(1,2))
  result <- lapply(cfg$STATISTICS,function(stat) {
    wt <- if(stat=="Energy") rep(1,kk) else 1/seq_len(kk)^2
    tobs <- numeric(np); tboot <- matrix(0,cfg$BOOT_B,np)
    for(j in seq_len(np)) {
      ix <- (j-1L)*kk+seq_len(kk)
      tobs[j] <- m*sum(wt*means[ix]^2)
      tboot[,j] <- colSums(sweep(gg[ix,,drop=FALSE]^2,1,wt,"*"))
    }
    obs <- c(tobs,max(tobs[endpoint]),max(tobs))
    bst <- cbind(tboot,apply(tboot[,endpoint,drop=FALSE],1,max),apply(tboot,1,max))
    pv <- vapply(seq_along(obs),function(j)
      (1+sum(bst[,j]>=obs[j]))/(cfg$BOOT_B+1),numeric(1))
    data.frame(test=stat,method=c(sprintf("p=%.2f",cfg$P_GRID),"Endpoint-union","Adaptive-p"),
      p=c(cfg$P_GRID,NA_real_,NA_real_),statistic=obs,pvalue=pv,
      selected_p=c(cfg$P_GRID,cfg$P_GRID[endpoint[which.max(tobs[endpoint])]],
                   cfg$P_GRID[which.max(tobs)]),block_length=ell,covariance_rank=rank)
  })
  do.call(rbind,result)
}

lpqp_design <- function(cfg,models) {
  if(identical(cfg$RUN_SCOPE,"null_check")) return(data.frame(
    model="amplitude_only",n=400L,rho=0,epsilon=0.03,dynamics="iid",cell_id=1L))
  rows <- list()
  for(model in names(models)) for(n in cfg$N) for(rho in cfg$RHO) {
    eps <- if(model=="amplitude_only") cfg$EPSILON else 0
    modes <- if(rho==0) "iid" else if(model=="amplitude_only") "persistent" else
      c("persistent","cycle4")
    for(e in eps) for(dyn in modes) rows[[length(rows)+1L]] <- data.frame(
      model=model,n=as.integer(n),rho=rho,epsilon=e,dynamics=dyn)
  }
  dd <- do.call(rbind,rows); dd$cell_id <- seq_len(nrow(dd)); dd
}

lpqp_one_replication <- function(task,cfg,models) {
  assign(".Random.seed",task$rng,envir=.GlobalEnv)
  dd <- task$cell; model <- models[[dd$model]]; model$epsilon <- dd$epsilon
  y <- lpqp_generate(dd$n,dd$rho,dd$dynamics,model)$y
  est <- if(cfg$INCLUDE_ORACLE) c("fitted","oracle") else "fitted"
  truth <- vapply(cfg$P_GRID,function(p) lpqp_population(p,model)$chi,numeric(1))
  isnull <- if(dd$rho==0) rep(TRUE,length(truth)) else truth<1e-18
  ep <- cfg$P_GRID %in% c(1,2)
  nulls <- c(isnull,all(isnull[ep]),all(isnull))
  ans <- lapply(est,function(e) {
    ss <- lpqp_score_matrix(y,cfg$P_GRID,e); fit <- lpqp_test(ss$scores,cfg)
    fit$reject <- as.integer(fit$pvalue<=cfg$LEVEL)
    fit$population_chi <- rep(c(truth,NA_real_,NA_real_),length(cfg$STATISTICS))
    fit$interpretation <- rep(ifelse(nulls,"score-null","score-alternative"),length(cfg$STATISTICS))
    fit$location <- rep(c(ss$location,NA_real_,NA_real_),length(cfg$STATISTICS))
    data.frame(cell_id=dd$cell_id,model=dd$model,dynamics=dd$dynamics,n=dd$n,
      rho=dd$rho,epsilon=dd$epsilon,replication=task$replication,estimator=e,
      process_null=dd$rho==0,calibration=cfg$CALIBRATION,fit)
  })
  do.call(rbind,ans)
}

lpqp_wilson <- function(k,n) {
  z <- qnorm(0.975); ph <- k/n; mid <- (ph+z*z/(2*n))/(1+z*z/n)
  half <- z*sqrt(ph*(1-ph)/n+z*z/(4*n*n))/(1+z*z/n)
  c(max(0,mid-half),min(1,mid+half))
}
lpqp_summarize <- function(raw) {
  keys <- c("cell_id","model","dynamics","n","rho","epsilon","estimator","test","method")

  groups <- split(seq_len(nrow(raw)),paste(raw$cell_id,raw$estimator,raw$test,raw$method,sep="|"))
  ans <- lapply(groups,function(ix) {
    a <- raw[ix,,drop=FALSE]; nn <- nrow(a); nr <- sum(a$reject); ci <- lpqp_wilson(nr,nn)
    data.frame(a[1,c(keys,"p","population_chi","interpretation","process_null"),drop=FALSE],
      replications=nn,rejections=nr,rejection_rate=nr/nn,
      mcse=sqrt((nr/nn)*(1-nr/nn)/nn),lower95=ci[1],upper95=ci[2])
  })
  out <- do.call(rbind,ans); rownames(out) <- NULL
  out[order(out$cell_id,out$estimator,out$test,is.na(out$p),out$p,out$method),]
}

lpqp_paired_gains <- function(raw) {
  a <- raw[raw$method=="Adaptive-p",]
  comparators <- intersect(c("Endpoint-union","p=1.00","p=1.50","p=2.00"),unique(raw$method))
  out <- list()
  for(comp in comparators) {
    b <- raw[raw$method==comp,]
    key <- function(x) paste(x$cell_id,x$estimator,x$test,x$replication,sep="|")
    ii <- match(key(a),key(b)); stopifnot(!anyNA(ii))
    diff <- a$reject-b$reject[ii]
    groups <- split(seq_len(nrow(a)),paste(a$cell_id,a$estimator,a$test,sep="|"))
    for(ix in groups) {
      d <- diff[ix]; nr <- length(d); se <- if(nr>1) sd(d)/sqrt(nr) else NA_real_
      base <- a[ix[1],c("cell_id","model","dynamics","n","rho","epsilon","estimator","test","process_null")]
      out[[length(out)+1L]] <- data.frame(base,comparator=comp,replications=nr,
        adaptive_rate=mean(a$reject[ix]),comparator_rate=mean(b$reject[ii[ix]]),
        paired_gain=mean(d),paired_mcse=se,
        lower95=max(-1,mean(d)-qnorm(.975)*se),upper95=min(1,mean(d)+qnorm(.975)*se))
    }
  }
  do.call(rbind,out)
}

lpqp_save_rds <- function(object,path) {
  tmp <- paste0(path,".tmp"); saveRDS(object,tmp,version=2)
  if(!file.rename(tmp,path)) {
    if(!file.copy(tmp,path,overwrite=TRUE)) stop("Cannot save ",path)
    unlink(tmp)
  }
}

lpqp_population_outputs <- function(cfg,models,outdir) {
  fine <- sort(unique(c(seq(1,2,length.out=401),cfg$P_GRID)))
  pp <- list(); sp <- list(); checks <- list()
  for(nm in names(models)) {
    eps <- if(nm=="amplitude_only") cfg$EPSILON else 0
    for(e in eps) {
      mm <- models[[nm]]; mm$epsilon <- e
      z <- do.call(rbind,lapply(fine,function(p) lpqp_population(p,mm)))
      pp[[length(pp)+1L]] <- data.frame(model=nm,epsilon=e,z)
      blind <- switch(nm,endpoints_blind=c(1,2),amplitude_only=1,interior_blind=1.5)
      for(p in blind) checks[[length(checks)+1L]] <- data.frame(
        check=paste(nm,"epsilon",e,"zero conditional score at p",p),
        error=abs(lpqp_population(p,mm)$conditional_mean),tolerance=1e-12)
      for(dyn in c("persistent","cycle4")) for(p in cfg$P_GRID) {
        chi <- lpqp_population(p,mm)$chi; ww <- seq(0,pi,length.out=801)
        sp[[length(sp)+1L]] <- data.frame(model=nm,epsilon=e,dynamics=dyn,rho=0.85,p=p,
          frequency=ww/(2*pi),normalized_density=lpqp_spectrum(ww,.85,chi,dyn),
          R=lpqp_shape(ww,.85,chi,dyn))
        val <- integrate(function(w) lpqp_spectrum(w,.85,chi,dyn),0,pi,rel.tol=1e-10)$value/pi
        checks[[length(checks)+1L]] <- data.frame(
          check=paste(nm,e,dyn,"spectral mass",p),error=abs(val-1),tolerance=1e-9)
        exact <- lpqp_shape(ww,.85,chi,dyn)
        stopifnot(all(diff(exact)>-1e-12),abs(exact[1])<1e-12,abs(tail(exact,1)-1)<1e-12)
      }
    }
  }
  pp <- do.call(rbind,pp); write.csv(pp,file.path(outdir,"population_visibility.csv"),row.names=FALSE)
  write.csv(do.call(rbind,sp),file.path(outdir,"population_spectra.csv"),row.names=FALSE)
  chk <- do.call(rbind,checks); chk$passed <- chk$error<=chk$tolerance
  write.csv(chk,file.path(outdir,"population_checks.csv"),row.names=FALSE)
  if(!all(chk$passed)) stop("Population verification failed.")

  de <- lpqp_design(cfg,models); signal <- list()
  for(i in seq_len(nrow(de))) {
    d <- de[i,]; mm <- models[[d$model]]; mm$epsilon <- d$epsilon
    for(p in cfg$P_GRID) {
      chi <- lpqp_population(p,mm)$chi
      rr <- lpqp_acf(seq_len(cfg$LAG_MAX),d$rho,chi,d$dynamics)
      signal[[length(signal)+1L]] <- data.frame(d,p=p,chi=chi,
        energy_signal=(d$n-cfg$LAG_MAX)*sum(rr^2),
        cvm_signal=(d$n-cfg$LAG_MAX)*sum(rr^2/seq_len(cfg$LAG_MAX)^2))
    }
  }
  write.csv(do.call(rbind,signal),file.path(outdir,"population_signal.csv"),row.names=FALSE)
  peaks <- lapply(split(pp,paste(pp$model,pp$epsilon)),function(d) d[which.max(d$chi),])
  write.csv(do.call(rbind,peaks),file.path(outdir,"population_best_p.csv"),row.names=FALSE)
}

lpqp_validate_config <- function(cfg) {
  stopifnot(length(cfg$N)>0,all(cfg$N>=64),all(cfg$N==as.integer(cfg$N)),
    all(cfg$P_GRID>=1 & cfg$P_GRID<=2),!anyDuplicated(cfg$P_GRID),all(c(1,2) %in% cfg$P_GRID),
    cfg$LAG_MAX>=2,cfg$LAG_MAX<min(cfg$N)/4,
    all(cfg$RHO>=0 & cfg$RHO<1),!anyDuplicated(cfg$RHO),
    length(cfg$EPSILON)>0,all(cfg$EPSILON>=0 & cfg$EPSILON<1),
    !anyDuplicated(cfg$EPSILON),cfg$OUTLIER_SCALE>cfg$EMISSION$b,
    cfg$AMPLITUDE_NEGATIVE>0,cfg$AMPLITUDE_NEGATIVE<cfg$EMISSION$b,
    cfg$AMPLITUDE_STRENGTH>0,cfg$AMPLITUDE_STRENGTH<=1,
    cfg$REPLICATIONS>=1,cfg$BOOT_B>=99,cfg$LEVEL>0,cfg$LEVEL<1,
    cfg$CHUNK_SIZE>=1,cfg$CORES>=1,length(cfg$STATISTICS)>0,
    all(cfg$STATISTICS %in% c("Energy","CvM")),!anyDuplicated(cfg$STATISTICS),
    cfg$CALIBRATION %in% c("permutation","model_null","hac"),
    cfg$EMISSION$a>0,cfg$EMISSION$a<cfg$EMISSION$b,cfg$EMISSION$b<cfg$EMISSION$c,
    cfg$EMISSION$jitter>0,cfg$EMISSION$jitter<1,
    cfg$EMISSION$interior_positive_prob>0.5,cfg$EMISSION$interior_positive_prob<1,
    cfg$EMISSION$central_prob>0,cfg$EMISSION$central_prob<1,cfg$EMISSION$central_scale>0)
  if(identical(cfg$RUN_SCOPE,"null_check")) stopifnot(identical(cfg$CALIBRATION,"permutation"),
    cfg$N==400L,cfg$RHO==0,cfg$EPSILON==0.03,cfg$LAG_MAX==8L,
    identical(as.numeric(cfg$P_GRID),c(1,1.15,1.25,1.35,1.5,1.75,2)))
  if(!is.null(cfg$MAIN_RESULTS_DIR)) {
    f <- file.path(cfg$MAIN_RESULTS_DIR,"rejection_summary.csv")
    if(!file.exists(f)) stop("Main simulation summary not found: ",f)
    old <- read.csv(f)
    required <- c("model","n","rho","epsilon","estimator","test","method",
      "replications","rejections","rejection_rate","lower95","upper95")
    if(!all(required %in% names(old))) stop("Main simulation summary is missing required columns")
    if(!any(old$model=="amplitude_only" & old$n==400 & old$rho==0 &
      abs(old$epsilon-.03)<1e-12 & old$estimator=="fitted",na.rm=TRUE))
      stop("Main simulation summary does not contain the target setting")
  }
  invisible(TRUE)
}

lpqp_run <- function(cfg) {
  lpqp_validate_config(cfg)
  dir.create(cfg$OUTPUT_DIR,recursive=TRUE,showWarnings=FALSE)
  outdir <- normalizePath(cfg$OUTPUT_DIR,mustWork=TRUE)
  ckdir <- file.path(outdir,"checkpoints"); dir.create(ckdir,showWarnings=FALSE)
  signature <- list(code_version=LPQP_CODE_VERSION,
    source_md5=unname(tools::md5sum(LPQP_SOURCE_FILE)),
    config=cfg[setdiff(names(cfg),c("CORES","RESUME","OUTPUT_DIR"))])
  manifest <- file.path(outdir,"configuration.rds")
  if(file.exists(manifest)) {
    if(!identical(readRDS(manifest)$signature,signature))
      stop("Code or configuration differs from saved run. Choose a new OUTPUT_DIR.")
    if(!cfg$RESUME) stop("Output exists; use RESUME=TRUE or a new OUTPUT_DIR.")
  } else lpqp_save_rds(list(signature=signature,config=cfg),manifest)
  models <- lpqp_models(cfg); design <- lpqp_design(cfg,models)
  write.csv(design,file.path(outdir,"design.csv"),row.names=FALSE)
  capture.output(sessionInfo(),file=file.path(outdir,"sessionInfo.txt"))
  lpqp_population_outputs(cfg,models,outdir)
  RNGkind("L'Ecuyer-CMRG"); set.seed(cfg$SEED); stream <- .Random.seed
  tasks <- vector("list",nrow(design)*cfg$REPLICATIONS); pos <- 0L
  for(i in seq_len(nrow(design))) for(rr in seq_len(cfg$REPLICATIONS)) {
    pos <- pos+1L; tasks[[pos]] <- list(cell=design[i,,drop=FALSE],replication=rr,rng=stream)
    stream <- parallel::nextRNGStream(stream)
  }
  cores <- min(as.integer(cfg$CORES),length(tasks)); cl <- NULL
  if(cores>1L) {
    cl <- parallel::makePSOCKcluster(cores); on.exit(parallel::stopCluster(cl),add=TRUE)
    env <- environment(lpqp_run); fn <- ls(envir=env,pattern="^lpqp_")
    parallel::clusterExport(cl,fn,envir=env)
    parallel::clusterExport(cl,c("cfg","models"),envir=environment())
  }
  allraw <- list(); nr <- cfg$REPLICATIONS; starttime <- proc.time()[3]
  for(i in seq_len(nrow(design))) {
    idx <- (i-1L)*nr+seq_len(nr); batches <- split(idx,ceiling(seq_along(idx)/cfg$CHUNK_SIZE))
    cellraw <- list()
    for(j in seq_along(batches)) {
      path <- file.path(ckdir,sprintf("cell_%03d_chunk_%04d.rds",i,j))
      if(cfg$RESUME && file.exists(path)) res <- readRDS(path) else {
        work <- tasks[batches[[j]]]
        res <- if(is.null(cl)) lapply(work,lpqp_one_replication,cfg=cfg,models=models) else
          parallel::parLapply(cl,work,lpqp_one_replication,cfg=cfg,models=models)
        lpqp_save_rds(res,path)
      }
      cellraw[[j]] <- do.call(rbind,res)
      message(sprintf("Cell %d/%d | %s %s n=%d rho=%.2f eps=%.2f | %d/%d | %.1f min",
        i,nrow(design),design$model[i],design$dynamics[i],design$n[i],design$rho[i],
        design$epsilon[i],min(j*cfg$CHUNK_SIZE,nr),nr,(proc.time()[3]-starttime)/60))
    }
    allraw[[i]] <- do.call(rbind,cellraw)
    write.csv(lpqp_summarize(do.call(rbind,allraw)),file.path(outdir,"rejection_summary.csv"),row.names=FALSE)
  }
  raw <- do.call(rbind,allraw); rownames(raw) <- NULL
  lpqp_save_rds(raw,file.path(outdir,"replication_results.rds"))
  write.csv(raw,file.path(outdir,"replication_results.csv"),row.names=FALSE)
  summary <- lpqp_summarize(raw)
  write.csv(summary,file.path(outdir,"rejection_summary.csv"),row.names=FALSE)
  write.csv(lpqp_paired_gains(raw),file.path(outdir,"paired_gains.csv"),row.names=FALSE)
  a <- raw[raw$method=="Adaptive-p",]
  sel <- aggregate(rep(1L,nrow(a)),a[c("cell_id","model","dynamics","n","rho","epsilon","estimator","test","selected_p")],sum)
  names(sel)[ncol(sel)] <- "count"; sel$proportion <- sel$count/cfg$REPLICATIONS
  write.csv(sel,file.path(outdir,"selected_p.csv"),row.names=FALSE)
  save(cfg,models,design,summary,file=file.path(outdir,"experiment.RData"))
  if(identical(cfg$RUN_SCOPE,"null_check")) lpqp_null_report(summary,cfg,outdir)
  message("Finished. Results: ",outdir,". Run 02_make_figures.R next.")
  invisible(list(config=cfg,summary=summary,raw=raw))
}

lpqp_null_report <- function(summary,cfg,outdir) {
  d <- summary
  d$binomial_p_upper <- mapply(function(k,n) pbinom(k-1,n,cfg$LEVEL,lower.tail=FALSE),
    d$rejections,d$replications)
  d$diagnostic_p_holm <- p.adjust(d$binomial_p_upper,"holm")
  write.csv(d,file.path(outdir,"null_verification.csv"),row.names=FALSE)
  fields <- c("test","method","replications","rejections","rejection_rate","lower95","upper95")
  comparison <- data.frame(source="independent_null",d[,fields])
  if(!is.null(cfg$MAIN_RESULTS_DIR)) {
    main <- read.csv(file.path(cfg$MAIN_RESULTS_DIR,"rejection_summary.csv"))
    main <- main[main$model=="amplitude_only" & main$n==400 & main$rho==0 &
      abs(main$epsilon-.03)<1e-12 & main$estimator=="fitted",]
    if(!nrow(main)) stop("Main simulation summary does not contain the target setting")
    comparison <- rbind(data.frame(source="main_simulation",main[,fields]),comparison)
  }
  write.csv(comparison,file.path(outdir,"null_comparison.csv"),row.names=FALSE)
}

LPQP_OVERRIDE <- getOption("lpqp.config",list())
LPQP_MODE <- if(is.null(LPQP_OVERRIDE$MODE)) "full" else LPQP_OVERRIDE$MODE
LPQP_TASK <- getOption("lpqp.task","main")
LPQP_CFG <- modifyList(lpqp_config(LPQP_MODE,LPQP_TASK),LPQP_OVERRIDE)
if(isTRUE(getOption("lpqp.autorun",TRUE))) lpqp_run(LPQP_CFG)
