lpqp_null_check_dir <- function() {
  files <- Filter(Negate(is.null),lapply(sys.frames(),function(x) x$ofile))
  if(length(files)) return(dirname(normalizePath(tail(files,1)[[1]],mustWork=TRUE)))
  args <- grep("^--file=",commandArgs(FALSE),value=TRUE)
  if(length(args)) return(dirname(normalizePath(sub("^--file=","",args[1]),mustWork=TRUE)))
  getwd()
}
LPQP_NULL_DIR <- lpqp_null_check_dir()

lpqp_run_null_check <- function() {
  root <- LPQP_NULL_DIR
  old <- options(lpqp.autorun=FALSE,lpqp.plot.autorun=FALSE)
  on.exit(options(old))
  env <- new.env(parent=.GlobalEnv)
  source(file.path(root,"01_run_experiment.R"),local=env)
  cfg <- env$lpqp_config("full","null_check")
  cfg <- modifyList(cfg,getOption("lpqp.null.config",list()))
  for(arg in commandArgs(trailingOnly=TRUE))
    if(grepl("^--cores=",arg)) cfg$CORES <- as.integer(sub("^--cores=","",arg))
  main <- file.path(root,"outputs","simulation")
  if(is.null(cfg$MAIN_RESULTS_DIR) && file.exists(file.path(main,"rejection_summary.csv")))
    cfg$MAIN_RESULTS_DIR <- main
  result <- env$lpqp_run(cfg)
  source(file.path(root,"02_make_figures.R"),local=env)
  env$lpqp_plot_all(cfg$OUTPUT_DIR)
  invisible(result)
}

if(!identical(getOption("lpqp.null.autorun"),FALSE)) LPQP_NULL_RESULT <- lpqp_run_null_check()
