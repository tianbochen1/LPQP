SETTINGS <- list(
  TASKS=c("simulation","null_check","calibration","dk1","btc"),
  CORES=8L,
  OUTPUT_ROOT=NULL,
  DK1_LOCAL_CSV=NULL,
  BTC_LOCAL_CSV=NULL,
  BTC_DATA_CACHE_DIR=NULL,
  MAKE_PLOTS=TRUE
)

lpqp_driver_dir <- function() {
  files <- Filter(Negate(is.null),lapply(sys.frames(),function(x) x$ofile))
  if(length(files)) return(dirname(normalizePath(tail(files,1)[[1]],mustWork=TRUE)))
  args <- grep("^--file=",commandArgs(FALSE),value=TRUE)
  if(length(args)) return(dirname(normalizePath(sub("^--file=","",args[1]),mustWork=TRUE)))
  getwd()
}
LPQP_DRIVER_DIR <- lpqp_driver_dir()

lpqp_load_module <- function(file) {
  old <- options(lpqp.autorun=FALSE,lpqp.plot.autorun=FALSE,cal.autorun=FALSE,
    dk1.autorun=FALSE,btc.autorun=FALSE,lpqp.application.figures.autorun=FALSE)
  on.exit(options(old))
  env <- new.env(parent=.GlobalEnv)
  source(file,local=env)
  env
}

lpqp_run_all <- function(settings=SETTINGS) {
  settings <- modifyList(settings,getOption("lpqp.run",list()))
  for(arg in commandArgs(trailingOnly=TRUE)) {
    if(grepl("^--tasks=",arg)) settings$TASKS <- strsplit(sub("^--tasks=","",arg),",",fixed=TRUE)[[1]]
    if(grepl("^--cores=",arg)) settings$CORES <- as.integer(sub("^--cores=","",arg))
  }
  order <- c("simulation","null_check","calibration","dk1","btc")
  stopifnot(length(settings$TASKS)>0,all(settings$TASKS%in%order),settings$CORES>=1)
  if(is.null(settings$OUTPUT_ROOT)) settings$OUTPUT_ROOT <- file.path(LPQP_DRIVER_DIR,"outputs")
  dir.create(settings$OUTPUT_ROOT,recursive=TRUE,showWarnings=FALSE)
  root <- normalizePath(settings$OUTPUT_ROOT,winslash="/",mustWork=TRUE)
  plots <- lpqp_load_module(file.path(LPQP_DRIVER_DIR,"02_make_figures.R"))
  app <- lpqp_load_module(file.path(LPQP_DRIVER_DIR,"05_make_application_figures.R"))
  result <- list()
  for(task in order[order%in%settings$TASKS]) {
    message("Starting ",task)
    if(task%in%c("simulation","null_check")) {
      env <- lpqp_load_module(file.path(LPQP_DRIVER_DIR,"01_run_experiment.R"))
      cfg <- env$lpqp_config("full",if(task=="simulation") "main" else "null_check")
      cfg$CORES <- settings$CORES
      cfg$OUTPUT_DIR <- file.path(root,task)
      if(task=="null_check" && file.exists(file.path(root,"simulation","rejection_summary.csv")))
        cfg$MAIN_RESULTS_DIR <- file.path(root,"simulation")
      env$lpqp_run(cfg)
      if(settings$MAKE_PLOTS) plots$lpqp_plot_all(cfg$OUTPUT_DIR)
      result[[task]] <- cfg$OUTPUT_DIR
    }
    if(task=="calibration") {
      env <- lpqp_load_module(file.path(LPQP_DRIVER_DIR,"04_bootstrap_calibration.R"))
      cfg <- env$cal_config(list(MODE="full",CORES=settings$CORES,OUTPUT_DIR=file.path(root,task)))
      env$cal_run(cfg)
      if(settings$MAKE_PLOTS) plots$lpqp_plot_all(cfg$OUTPUT_DIR)
      result[[task]] <- cfg$OUTPUT_DIR
    }
    if(task=="dk1") {
      env <- lpqp_load_module(file.path(LPQP_DRIVER_DIR,"DK1_LpQP_all_in_one.R"))
      cfg <- env$CFG
      cfg$CORES <- settings$CORES
      cfg$LOCAL_CSV <- settings$DK1_LOCAL_CSV
      cfg$OUTPUT_DIR <- file.path(root,task)
      analysis <- env$dk1_run(cfg)
      if(settings$MAKE_PLOTS) app$lpqp_plot_dk1(analysis,file.path(root,task,"results","frame"))
      result[[task]] <- file.path(root,task,"results")
      rm(analysis)
    }
    if(task=="btc") {
      env <- lpqp_load_module(file.path(LPQP_DRIVER_DIR,"BTCUSDT_LpQP_all_in_one.R"))
      cfg <- env$CFG
      cfg$CORES <- settings$CORES
      cfg$LOCAL_CSV <- settings$BTC_LOCAL_CSV
      cfg$DATA_CACHE_DIR <- settings$BTC_DATA_CACHE_DIR
      cfg$OUTPUT_DIR <- file.path(root,task)
      cfg$MAKE_PLOTS <- settings$MAKE_PLOTS
      env$btc_run(cfg,file.path(LPQP_DRIVER_DIR,"BTCUSDT_LpQP_all_in_one.R"))
      result[[task]] <- file.path(root,task,"results")
    }
    message("Completed ",task)
  }
  if(settings$MAKE_PLOTS) {
    destination <- file.path(root,"frame")
    dir.create(destination,showWarnings=FALSE)
    figures <- list(
      simulation=c("population_visibility.pdf","population_spectra.pdf","endpoint_power.pdf","contamination_power.pdf"),
      dk1=c("dk1_spectra.pdf","dk1_band_mass.pdf"),
      btc="btc_profiles.pdf"
    )
    for(task in intersect(names(figures),names(result))) {
      files <- file.path(result[[task]],"frame",figures[[task]])
      if(!all(file.exists(files))) stop("Expected figure missing for ",task)
      if(!all(file.copy(files,destination,overwrite=TRUE))) stop("Cannot collect figures for ",task)
    }
  }
  invisible(result)
}

if(!identical(getOption("lpqp.run.autorun"),FALSE)) LPQP_OUTPUTS <- lpqp_run_all()
