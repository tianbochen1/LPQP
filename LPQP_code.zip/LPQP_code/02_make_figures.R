lpqp_plot_script_dir <- function() {
  ff <- sys.frames()
  of <- unlist(lapply(ff,function(x) if(!is.null(x$ofile)) x$ofile else NULL))
  if(length(of)) return(dirname(normalizePath(tail(of,1),mustWork=FALSE)))
  ar <- commandArgs(FALSE); ar <- ar[startsWith(ar,"--file=")]
  if(length(ar)) return(dirname(normalizePath(sub("--file=","",ar[1]),mustWork=FALSE)))
  getwd()
}
lpqp_plot_pair <- function(path,width,height,draw) {
  pdf(paste0(path,".pdf"),width=width,height=height,family="Helvetica",useDingbats=FALSE,
      useKerning=FALSE,pointsize=10)
  tryCatch(draw(),finally=dev.off())
  if(isTRUE(getOption("lpqp.png",TRUE))) {
    png(paste0(path,".png"),width=width,height=height,units="in",res=300,pointsize=10)
    tryCatch(draw(),finally=dev.off())
  }
}
lpqp_plot_style <- function() {
  par(family="sans",cex=1,las=1,tcl=-0.25,mgp=c(2.25,.65,0),
      mar=c(3.7,4,2.4,.8),cex.axis=.87,cex.lab=.94,cex.main=.98)
}
lpqp_bottom_legend <- function(labels,colors,lty=1,pch=NA,cex=.85) {
  par(fig=c(0,1,0,.065),new=TRUE,mar=rep(0,4),oma=rep(0,4)); plot.new()
  legend("center",legend=labels,col=colors,lty=lty,pch=pch,lwd=1.7,
         horiz=TRUE,bty="n",cex=cex,x.intersp=.6)
}
lpqp_p_panel <- function(d,nvals,colors,title,level) {
  plot(NA,xlim=c(.98,2.40),ylim=c(0,1),xaxt="n",xlab="Power p and joint tests",
       ylab="Rejection probability",main=title)
  axis(1,at=c(1,1.25,1.5,1.75,2,2.17,2.34),
       labels=c("1","1.25","1.5","1.75","2","Ends","Adapt"),cex.axis=.79)
  abline(h=level,lty=3,col="grey45")
  abline(v=c(1,2),lty=3,col="grey85")
  for(j in seq_along(nvals)) {
    dd <- d[d$n==nvals[j] & !is.na(d$p),]; dd <- dd[order(dd$p),]
    lines(dd$p,dd$rejection_rate,type="b",lwd=1.6,col=colors[j],pch=14+j,cex=.7)
    arrows(dd$p,dd$lower95,dd$p,dd$upper95,angle=90,code=3,length=.02,
           col=adjustcolor(colors[j],alpha.f=.6))
    for(k in 1:2) {
      jj <- d[d$n==nvals[j] & d$method==c("Endpoint-union","Adaptive-p")[k],]
      xx <- c(2.17,2.34)[k]+(j-(length(nvals)+1)/2)*.018
      points(xx,jj$rejection_rate,pch=14+j,col=colors[j],cex=.85)
      arrows(xx,jj$lower95,xx,jj$upper95,angle=90,code=3,length=.02,col=colors[j])
    }
  }
}

lpqp_plot_all <- function(outdir) {
  if(!file.exists(file.path(outdir,"configuration.rds"))) stop("Run 01_run_experiment.R first.")
  cfg <- readRDS(file.path(outdir,"configuration.rds"))$config
  scope <- if(is.null(cfg$RUN_SCOPE)) "main" else cfg$RUN_SCOPE
  if(scope=="null_check") return(lpqp_plot_null(outdir,cfg))
  if(scope=="calibration") return(lpqp_plot_calibration(outdir,cfg))
  read <- function(nm) read.csv(file.path(outdir,nm),stringsAsFactors=FALSE)
  pop <- read("population_visibility.csv"); spectra <- read("population_spectra.csv")
  res <- read("rejection_summary.csv"); gains <- read("paired_gains.csv")
  if(!all(read("population_checks.csv")$passed)) stop("Population checks failed.")
  res <- res[res$estimator=="fitted",]; gains <- gains[gains$estimator=="fitted",]
  nvals <- sort(unique(res$n)); rhos <- sort(unique(res$rho[res$rho>0]))
  nmax <- max(nvals); rhomax <- max(rhos)
  tests <- cfg$STATISTICS
  figdir <- file.path(outdir,"figures"); dir.create(figdir,showWarnings=FALSE)
  cols <- c("#0072B2","#D55E00","#009E73","#8C61A8","#4D4D4D","#E69F00")

  lpqp_plot_pair(file.path(figdir,"figure1_mechanisms"),10.3,3.5,function() {
    par(mfrow=c(1,3)); lpqp_plot_style()
    d <- pop[pop$model=="endpoints_blind",]
    plot(d$p,d$chi,type="l",lwd=2.3,col=cols[1],ylim=c(0,max(d$chi)*1.18),
         xlab="Power p",ylab="Signal strength",main="A. Endpoints miss the signal")
    points(c(1,2),c(0,0),pch=21,bg="white",cex=1.2)
    best <- d[which.max(d$chi),]; points(best$p,best$chi,pch=19,col=cols[2])
    text(best$p,best$chi,sprintf("peak at p = %.3f",best$p),pos=3,cex=.8)
    d <- pop[pop$model=="amplitude_only",]; eps <- sort(unique(d$epsilon))
    plot(NA,xlim=c(1,2),ylim=c(0,max(d$chi)*1.05),xlab="Power p",ylab="Signal strength",
         main="B. Outliers shift the useful p")
    for(j in seq_along(eps)) {
      dd <- d[d$epsilon==eps[j],]
      lines(dd$p,dd$chi,lwd=1.9,col=cols[j],lty=j)
      bb <- dd[which.max(dd$chi),]; points(bb$p,bb$chi,pch=19,col=cols[j],cex=.7)
    }
    legend("topleft",sprintf("Outliers: %g%%",100*eps),col=cols[seq_along(eps)],
           lty=seq_along(eps),lwd=1.8,bty="n",cex=.73)
    d <- spectra[spectra$model=="endpoints_blind" & spectra$dynamics=="cycle4",]
    pp <- unique(c(1,cfg$P_GRID[which.min(abs(cfg$P_GRID-1.35))],2))
    plot(NA,xlim=c(0,.5),ylim=range(c(1,d$normalized_density)),
         xlab="Frequency (cycles / observation)",ylab="Normalized spectral density",
         main="C. Hidden oscillation, rho = 0.85")
    abline(v=.25,lty=3,col="grey80")
    for(j in seq_along(pp)) {
      dd <- d[abs(d$p-pp[j])<1e-10,]
      lines(dd$frequency,dd$normalized_density,col=cols[j],lwd=2,lty=j)
    }
    legend("topright",sprintf("p = %.2f",pp),col=cols[seq_along(pp)],
           lty=seq_along(pp),lwd=2,bty="n",cex=.75)
  })

  for(rho in rhos) {
    suffix <- gsub("\\.","",sprintf("%.2f",rho))
    lpqp_plot_pair(file.path(figdir,paste0("figure2_hidden_dependence_rho_",suffix)),
                   8.5,3.15*length(tests),function() {
      par(mfrow=c(length(tests),2),oma=c(2.2,0,1,0)); lpqp_plot_style()
      for(test in tests) for(dyn in c("persistent","cycle4")) {
        d <- res[res$model=="endpoints_blind" & res$test==test &
                   res$dynamics==dyn & res$rho==rho,]
        title <- paste(test,if(dyn=="persistent") "persistence" else "oscillation",sep=" | ")
        lpqp_p_panel(d,nvals,cols,title,cfg$LEVEL)
      }
      mtext(sprintf("Endpoint cancellation | rho = %.2f | Ends = endpoint union; Adapt = p scan",rho),
            side=3,outer=TRUE,line=-.5,cex=.9)
      lpqp_bottom_legend(paste("n =",nvals),cols[seq_along(nvals)],pch=14+seq_along(nvals))
    })
  }

  methods <- intersect(c("p=1.00","p=1.50","p=2.00","Endpoint-union","Adaptive-p"),unique(res$method))
  mcols <- c("#777777","#009E73","#0072B2","#E69F00","#9C3E76")[seq_along(methods)]
  mlty <- c(3,2,1,4,1)[seq_along(methods)]
  lpqp_plot_pair(file.path(figdir,"figure3_contamination"),4.1*length(nvals),3.15*length(tests),function() {
    par(mfrow=c(length(tests),length(nvals)),oma=c(2.2,0,1,0)); lpqp_plot_style()
    for(test in tests) for(nn in nvals) {
      d <- res[res$model=="amplitude_only" & res$test==test & res$n==nn &
                 res$rho==rhomax,]
      plot(NA,xlim=range(100*cfg$EPSILON)+c(-.08,.08),ylim=c(0,1),
           xlab="Replacement outliers (%)",ylab="Rejection probability",
           main=sprintf("%s | n = %d",test,nn))
      abline(h=cfg$LEVEL,lty=3,col="grey70")
      a <- d[d$method=="Adaptive-p",]; a <- a[order(a$epsilon),]
      polygon(c(100*a$epsilon,rev(100*a$epsilon)),c(a$lower95,rev(a$upper95)),
              col=adjustcolor("#9C3E76",alpha.f=.13),border=NA)
      for(j in seq_along(methods)) {
        dd <- d[d$method==methods[j],]; dd <- dd[order(dd$epsilon),]
        lines(100*dd$epsilon,dd$rejection_rate,type="b",col=mcols[j],lty=mlty[j],
              lwd=if(methods[j]=="Adaptive-p") 2.5 else 1.5,pch=14+j,cex=.65)
      }
    }
    mtext(sprintf("Amplitude dependence | rho = %.2f | outlier magnitude = %g | shading: Adaptive-p 95%% MC interval",rhomax,cfg$OUTLIER_SCALE),
          side=3,outer=TRUE,line=-.5,cex=.9)
    lpqp_bottom_legend(methods,mcols,mlty,pch=14+seq_along(methods),cex=.78)
  })

  lpqp_plot_pair(file.path(figdir,"figure4_adaptive_gain"),8.5,4.8,function() {
    lpqp_plot_style(); par(mar=c(4.2,12,2.6,1))
    d <- gains[gains$test==tests[1] & gains$n==nmax & gains$rho==rhomax &
                 gains$comparator=="Endpoint-union",]
    ordermodel <- match(d$model,c("endpoints_blind","amplitude_only","interior_blind"))
    d <- d[order(ordermodel,d$epsilon,-as.numeric(d$dynamics=="persistent")),]
    lab <- ifelse(d$model=="amplitude_only",sprintf("Amplitude | outliers %g%%",100*d$epsilon),
      paste(ifelse(d$model=="endpoints_blind","Endpoint cancellation","Interior cancellation"),
            ifelse(d$dynamics=="persistent","persistence","oscillation"),sep=" | "))
    yy <- rev(seq_len(nrow(d))); xr <- range(c(-.12,d$lower95,d$upper95))+c(-.025,.025)
    plot(d$paired_gain,yy,xlim=xr,ylim=c(.5,nrow(d)+.5),yaxt="n",pch=19,col="#9C3E76",
         xlab="Adaptive-p minus endpoint-union rejection probability",ylab="",
         main=sprintf("%s | n = %d | rho = %.2f | paired 95%% MC intervals",tests[1],nmax,rhomax))
    axis(2,at=yy,labels=lab,las=1,cex.axis=.8); abline(v=0,lty=2,col="grey55")
    ok <- d$upper95>d$lower95
    arrows(d$lower95[ok],yy[ok],d$upper95[ok],yy[ok],angle=90,code=3,length=.035,col="#9C3E76",lwd=1.5)
  })

  lpqp_plot_pair(file.path(figdir,"figure5_iid_size"),11,3.0*length(tests)+.4,function() {
    par(mfrow=c(length(tests),3),oma=c(2.6,0,1,0)); lpqp_plot_style()
    mods <- c("endpoints_blind","amplitude_only","interior_blind")
    labs <- c("Endpoint cancellation","Amplitude / outliers","Interior cancellation")
    meth <- c(sprintf("p=%.2f",cfg$P_GRID),"Endpoint-union","Adaptive-p")
    pal <- colorRampPalette(c("#c5ddea","#f5f5f5","#e5a380","#b4483c"))(101)
    d0 <- res[res$process_null,]; upper <- max(.15,max(d0$rejection_rate))
    for(test in tests) for(j in seq_along(mods)) {
      d <- d0[d0$test==test & d0$model==mods[j],]
      cases <- unique(d[c("n","epsilon")]); cases <- cases[order(cases$n,cases$epsilon),]
      mat <- matrix(NA_real_,length(meth),nrow(cases))
      for(k in seq_len(nrow(cases))) {
        dd <- d[d$n==cases$n[k] & d$epsilon==cases$epsilon[k],]
        mat[,k] <- dd$rejection_rate[match(meth,dd$method)]
      }
      par(mar=c(4.4,4.8,2.4,.6))
      image(seq_along(meth),seq_len(ncol(mat)),mat,zlim=c(0,upper),col=pal,axes=FALSE,
            xlab="",ylab="",main=paste(labs[j],test,sep=" | "))
      axis(1,at=seq_along(meth),labels=c(sprintf("%.2f",cfg$P_GRID),"Ends","Adapt"),las=2,cex.axis=.8)
      axis(2,at=seq_len(nrow(cases)),labels=sprintf("%d / %g%%",cases$n,100*cases$epsilon),las=1,cex.axis=.74)
      for(k in seq_len(ncol(mat))) text(seq_along(meth),k,sprintf("%.2f",mat[,k]),cex=.66)
      mtext("n / outliers",side=2,line=3.6,las=0,cex=.8); box()
    }
    mtext(sprintf("All matched iid controls | nominal level = %.2f | pointwise Monte Carlo intervals reported separately",cfg$LEVEL),
          side=3,outer=TRUE,line=-.5,cex=.9)
    par(fig=c(.3,.7,.065,.10),new=TRUE,mar=c(0,0,0,0),oma=rep(0,4))
    image(seq(0,upper,length.out=101),1,matrix(seq(0,upper,length.out=101),101,1),
          col=pal,axes=FALSE,xlab="",ylab="")
    axis(1,at=pretty(c(0,upper),3),cex.axis=.75,tcl=-.2)
  })

  lpqp_plot_pair(file.path(figdir,"figure6_complementarity_control"),8.5,3.8,function() {
    par(mfrow=c(1,2),oma=c(1,0,0,0)); lpqp_plot_style()
    d <- pop[pop$model=="interior_blind",]
    plot(d$p,d$chi,type="l",lwd=2,col=cols[1],xlab="Power p",ylab="Signal strength",
         main="Control: p = 1.5 misses the signal")
    abline(v=1.5,lty=3,col="grey60"); points(1.5,0,pch=21,bg="white",cex=1.2)
    d <- res[res$model=="interior_blind" & res$test==tests[1] & res$n==nmax & res$rho==rhomax,]
    ds <- c("persistent","cycle4")

    d$n <- match(d$dynamics,ds)
    lpqp_p_panel(d,1:2,cols,sprintf("%s | n = %d | rho = %.2f",tests[1],nmax,rhomax),cfg$LEVEL)
    legend("top",c("Persistence","Oscillation"),col=cols[1:2],pch=15:16,lty=1,
           bty="n",cex=.75)
  })

  write.csv(res[res$process_null,],file.path(outdir,"table_iid_size.csv"),row.names=FALSE)
  write.csv(res[!res$process_null & res$interpretation=="score-null",],
            file.path(outdir,"table_dependent_score_null.csv"),row.names=FALSE)
  write.csv(res[!res$process_null,],file.path(outdir,"table_dependence_rejections.csv"),row.names=FALSE)
  write.csv(gains[!gains$process_null,],file.path(outdir,"table_adaptive_gains.csv"),row.names=FALSE)
  main <- res[res$test==tests[1] & !res$process_null & res$method %in% methods,]
  write.csv(main,file.path(outdir,"table_main_comparison.csv"),row.names=FALSE)
  bs <- intToUtf8(92); eol <- paste0(bs,bs); esc <- function(x) gsub("_",paste0(bs,"_"),x,fixed=TRUE)
  lines <- c(paste0(bs,"begin{longtable}{llrrrlrr}"),paste0(bs,"toprule"),
    paste0("Model & Dynamics & $n$ & $",bs,"rho$ & Outliers & Method & Rejection & MCSE ",eol),
    paste0(bs,"midrule"),paste0(bs,"endhead"))
  for(i in seq_len(nrow(main))) lines <- c(lines,paste0(sprintf(
    "%s & %s & %d & %.2f & %.2f & %s & %.3f & %.3f ",esc(main$model[i]),
    esc(main$dynamics[i]),main$n[i],main$rho[i],main$epsilon[i],main$method[i],
    main$rejection_rate[i],main$mcse[i]),eol))
  writeLines(c(lines,paste0(bs,"bottomrule"),paste0(bs,"end{longtable}")),
             file.path(outdir,"table_main_comparison.tex"))
  lpqp_paper_figures(outdir,cfg,pop,spectra,res)
  message("Figures and tables saved in ",outdir)
  invisible(res)
}

lpqp_supp_frame <- function(outdir) {
  d<-file.path(outdir,"frame");dir.create(d,recursive=TRUE,showWarnings=FALSE);d
}
lpqp_plot_null <- function(outdir,cfg) {
  d<-read.csv(file.path(outdir,"null_verification.csv"))
  old<-read.csv(file.path(outdir,"null_comparison.csv"))
  old<-old[old$source=="main_simulation",]
  methods<-c(sprintf("p=%.2f",cfg$P_GRID),"Endpoint-union","Adaptive-p")
  labels<-c(as.character(cfg$P_GRID),"EU","AS")
  lpqp_plot_pair(file.path(lpqp_supp_frame(outdir),"null_verification"),8.6,4.1,function() {
    layout(matrix(c(1,2,3,3),2,2,byrow=TRUE),heights=c(1,.22))
    for(stat in c("Energy","CvM")) {
      z<-d[d$test==stat,];z<-z[match(methods,z$method),]
      a<-old[old$test==stat,];x<-seq_along(methods)
      par(mar=c(4,4,2.6,.7),mgp=c(2.5,.65,0),cex.axis=.85)
      plot(x,z$rejection_rate,pch=16,col="#0072B2",xaxt="n",xlab="Power p / procedure",
        ylab="Rejection proportion",ylim=c(0,max(.10,z$upper95,a$upper95,na.rm=TRUE)),main=stat)
      axis(1,at=x,labels=labels);abline(h=cfg$LEVEL,lty=3,col="grey40")
      arrows(x,z$lower95,x,z$upper95,angle=90,code=3,length=.03,col="#0072B2")
      if(nrow(a)) points(match(a$method,methods)+.12,a$rejection_rate,pch=5,col="#D55E00",cex=1.1)
    }
    par(mar=rep(0,4));plot.new()
    legend("center",c("Independent null sample (95% MC interval)","Main simulation estimate"),
      col=c("#0072B2","#D55E00"),pch=c(16,5),bty="n",horiz=TRUE,cex=.85)
  })
  invisible(d)
}
lpqp_plot_calibration <- function(outdir,cfg) {
  d<-read.csv(file.path(outdir,"calibration_summary.csv"))
  d<-d[abs(d$nominal_level-cfg$LEVEL)<1e-12 & d$block_length==cfg$PRIMARY_BLOCK,]
  cases<-unique(d$case_id);cols<-c("#0072B2","#D55E00")
  for(K in cfg$K_GRID) lpqp_plot_pair(file.path(lpqp_supp_frame(outdir),paste0("bootstrap_null_K",K)),
    8.8,3.25*ceiling(length(cases)/2)+.6,function() {
      nr<-ceiling(length(cases)/2);panels<-matrix(seq_len(nr*2),nr,2,byrow=TRUE)
      layout(rbind(panels,rep(nr*2+1,2)),heights=c(rep(1,nr),.22))
      for(cid in cases) {
        a<-d[d$case_id==cid & d$K==K,]
        methods<-c("fixed_p","endpoint_union","adaptive_scan")
        lab<-c(as.character(cfg$P_GRID),"EU","AS")
        par(mar=c(3.6,4,2.2,.7),mgp=c(2.5,.6,0),cex.axis=.8)
        plot(NA,xlim=c(.7,length(lab)+.3),ylim=c(0,max(.10,a$upper95)),xaxt="n",
          xlab="Power p / procedure",ylab="Rejection proportion",
          main=paste0(if(a$innovation[1]=="normal") "Gaussian" else "Standardized t(5)",
            "; rounding step = ",a$round_step[1]))
        axis(1,at=seq_along(lab),labels=lab);abline(h=cfg$LEVEL,lty=3,col="grey40")
        for(j in 1:2) {
          z<-a[a$statistic==c("Energy","CvM")[j],]
          z<-z[order(match(z$method,methods),z$p,na.last=TRUE),]
          x<-seq_len(nrow(z))+(j-1.5)*.14
          points(x,z$rejection_rate,col=cols[j],pch=14+j)
          arrows(x,z$lower95,x,z$upper95,col=cols[j],angle=90,code=3,length=.025)
        }
      }
      if(length(cases)<nr*2) for(i in seq_len(nr*2-length(cases))) plot.new()
      par(mar=rep(0,4));plot.new();legend("center",c("Energy","CvM"),col=cols,pch=15:16,horiz=TRUE,bty="n")
    })
  invisible(d)
}
lpqp_paper_figures <- function(outdir,cfg,pop,spectra,res) {
  frame<-lpqp_supp_frame(outdir)
  cols<-c("#4477AA","#EE7733","#228877","#9955AA","#555555")
  style<-function() par(mar=c(3.8,4.2,2.3,.6),mgp=c(2.6,.65,0),cex.axis=.88,cex.lab=.95)
  lpqp_plot_pair(file.path(frame,"population_visibility"),8.6,3.4,function() {
    layout(matrix(c(1,2,3,4,4,4),2,3,byrow=TRUE),heights=c(1,.25))
    mods<-c("endpoints_blind","amplitude_only","interior_blind")
    for(i in 1:3) {
      d<-pop[pop$model==mods[i],];style()
      plot(NA,xlim=c(1,2),ylim=c(0,max(d$chi)*1.05),xlab="Power p",
        ylab=if(i==1) expression(chi[p]) else "",main=c("E: Endpoint cancellation","A: Independent replacement","I: Interior cancellation")[i],cex.main=.9)
      eps<-sort(unique(d$epsilon))
      for(j in seq_along(eps)) {a<-d[d$epsilon==eps[j],];a<-a[order(a$p),];lines(a$p,a$chi,col=cols[j],lwd=1.7)}
    }
    par(mar=rep(0,4));plot.new();legend("center",paste0("epsilon = ",cfg$EPSILON),
      col=cols[seq_along(cfg$EPSILON)],lty=1,lwd=1.7,bty="n",horiz=TRUE,cex=.85)
  })
  lpqp_plot_pair(file.path(frame,"population_spectra"),8.6,3.7,function() {
    layout(matrix(c(1,2,3,3),2,2,byrow=TRUE),heights=c(1,.23))
    powers<-c(1,1.15,1.35,1.5,1.75)
    for(dyn in c("persistent","cycle4")) {
      d<-spectra[spectra$model=="endpoints_blind" & spectra$dynamics==dyn,];style()
      plot(NA,xlim=c(0,.5),ylim=range(c(1,d$normalized_density)),xlab="Frequency (cycles per observation)",
        ylab="Normalized density",main=if(dyn=="persistent") "Persistent state" else "Four-state cycle")
      for(j in seq_along(powers)) {a<-d[abs(d$p-powers[j])<1e-10,];
        lines(a$frequency,a$normalized_density,col=cols[j],lwd=1.6,lty=if(j==1) 2 else 1)}
    }
    par(mar=rep(0,4));plot.new();legend("center",c("p = 1, 2",paste0("p = ",powers[-1])),col=cols,
      lty=c(2,1,1,1,1),lwd=1.6,horiz=TRUE,bty="n",cex=.85)
  })

  meth<-c("p=1.00","p=1.50","p=2.00","Endpoint-union","Adaptive-p")
  lab<-c("p = 1","p = 1.5","p = 2","Endpoint union","Adaptive scan")
  rhos<-sort(unique(res$rho[res$rho>0]))
  lpqp_plot_pair(file.path(frame,"endpoint_power"),8.6,3*length(rhos)+.6,function() {
    nr<-length(rhos);layout(rbind(matrix(seq_len(nr*2),nr,2,byrow=TRUE),rep(nr*2+1,2)),heights=c(rep(1,nr),.22))
    for(rho in rhos) for(dyn in c("persistent","cycle4")) {
      d<-res[res$model=="endpoints_blind" & res$test=="Energy" & res$rho==rho & res$dynamics==dyn,];style()
      plot(NA,xlim=range(d$n),ylim=c(0,1),xlab="Sample size",ylab="Rejection proportion",
        main=paste(if(dyn=="persistent") "Persistent" else "Cycle",", rho =",rho))
      abline(h=cfg$LEVEL,lty=3,col="grey60")
      for(j in seq_along(meth)) {a<-d[d$method==meth[j],];a<-a[order(a$n),];
        lines(a$n,a$rejection_rate,col=cols[j],pch=14+j,type="b",lty=j,lwd=1.5)}
    }
    par(mar=rep(0,4));plot.new();legend("center",lab,col=cols,lty=1:5,pch=15:19,horiz=TRUE,bty="n",cex=.8)
  })
  lpqp_plot_pair(file.path(frame,"contamination_power"),8.6,3.8,function() {
    layout(rbind(seq_along(rhos),rep(length(rhos)+1,length(rhos))),heights=c(1,.23))
    for(rho in rhos) {
      d<-res[res$model=="amplitude_only" & res$test=="Energy" & res$rho==rho & res$n==max(res$n),];style()
      plot(NA,xlim=range(100*d$epsilon),ylim=c(0,1),xlab="Replacement proportion (%)",ylab="Rejection proportion",main=paste("rho =",rho))
      abline(h=cfg$LEVEL,lty=3,col="grey60")
      for(j in seq_along(meth)) {a<-d[d$method==meth[j],];a<-a[order(a$epsilon),];
        lines(100*a$epsilon,a$rejection_rate,col=cols[j],pch=14+j,type="b",lty=j,lwd=1.5)}
    }
    par(mar=rep(0,4));plot.new();legend("center",lab,col=cols,lty=1:5,pch=15:19,horiz=TRUE,bty="n",cex=.8)
  })
}

LPQP_PLOT_BASE <- lpqp_plot_script_dir()
LPQP_RESULTS_DIR <- getOption("lpqp.results_dir",NULL)
if(is.null(LPQP_RESULTS_DIR)) {
  if(exists("LPQP_CFG") && file.exists(file.path(LPQP_CFG$OUTPUT_DIR,"configuration.rds")))
    LPQP_RESULTS_DIR <- LPQP_CFG$OUTPUT_DIR else {
      candidates <- file.path(LPQP_PLOT_BASE,c("outputs/simulation","outputs/null_check","outputs/calibration"))
      candidates <- candidates[file.exists(file.path(candidates,"configuration.rds"))]
      if(length(candidates)!=1L && isTRUE(getOption("lpqp.plot.autorun",TRUE)))
        stop("Set options(lpqp.results_dir='path/to/results') explicitly.")
      if(length(candidates)==1L) LPQP_RESULTS_DIR <- candidates[1]
    }
}
if(isTRUE(getOption("lpqp.plot.autorun",TRUE))) lpqp_plot_all(LPQP_RESULTS_DIR)
