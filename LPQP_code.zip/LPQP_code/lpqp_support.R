lpqs_path <- function() {
  f <- Filter(Negate(is.null), lapply(sys.frames(), function(x) x$ofile))
  if (length(f)) return(normalizePath(tail(f,1)[[1]],winslash="/",mustWork=TRUE))
  a <- grep("^--file=",commandArgs(FALSE),value=TRUE)
  if (length(a)) return(normalizePath(sub("^--file=","",a[1]),winslash="/",mustWork=TRUE))
  NA_character_
}
lpqs_save <- function(x,path,compress=FALSE) {
  dir.create(dirname(path),recursive=TRUE,showWarnings=FALSE)
  tmp <- paste0(path,".tmp-",Sys.getpid())
  saveRDS(x,tmp,version=2,compress=compress)
  if (!file.rename(tmp,path)) {
    if (!file.copy(tmp,path,overwrite=TRUE)) stop("Cannot save ",path)
    unlink(tmp)
  }
  invisible(path)
}
lpqs_csv <- function(x,path) write.csv(x,path,row.names=FALSE,na="",fileEncoding="UTF-8")
lpqs_rng_save <- function() list(kind=RNGkind(),
  seed=if(exists(".Random.seed",.GlobalEnv,inherits=FALSE)) get(".Random.seed",.GlobalEnv) else NULL)
lpqs_rng_restore <- function(x) {
  do.call(RNGkind,as.list(x$kind))
  if (is.null(x$seed)) {
    if (exists(".Random.seed",.GlobalEnv,inherits=FALSE)) rm(".Random.seed",envir=.GlobalEnv)
  } else assign(".Random.seed",x$seed,.GlobalEnv)
}
lpqs_streams <- function(n,seed) {
  old <- lpqs_rng_save(); on.exit(lpqs_rng_restore(old))
  RNGkind("L'Ecuyer-CMRG"); set.seed(seed)
  s <- get(".Random.seed",.GlobalEnv); ans <- vector("list",n)
  for(i in seq_len(n)) { ans[[i]] <- s; s <- parallel::nextRNGStream(s) }
  ans
}
lpqs_wilson <- function(k,n,level=.95) {
  z <- qnorm((1+level)/2); p <- k/n; den <- 1+z*z/n
  mid <- (p+z*z/(2*n))/den; half <- z*sqrt(p*(1-p)/n+z*z/(4*n*n))/den
  c(lower=max(0,mid-half),upper=min(1,mid+half))
}
lpqs_prepare <- function(cfg,files) {
  dir.create(cfg$OUTPUT_DIR,recursive=TRUE,showWarnings=FALSE)
  out <- normalizePath(cfg$OUTPUT_DIR,winslash="/",mustWork=TRUE)
  for(d in c("checkpoints","frame","logs")) dir.create(file.path(out,d),showWarnings=FALSE)

  sig <- list(config=cfg[setdiff(names(cfg),c("CORES","RESUME","OUTPUT_DIR"))],
    source_md5=setNames(unname(tools::md5sum(files)),basename(files)))
  if (anyNA(sig$source_md5)) stop("A required source file is missing")
  f <- file.path(out,"configuration.rds")
  if (file.exists(f)) {
    old <- readRDS(f)
    if (!identical(old$signature,sig)) stop("Configuration or code differs from checkpoints. Use a new OUTPUT_DIR.")
    if (!isTRUE(cfg$RESUME)) stop("Output already exists. Use RESUME=TRUE or a new OUTPUT_DIR.")
  } else lpqs_save(list(signature=sig,config=cfg),f)
  writeLines(capture.output(sessionInfo()),file.path(out,"sessionInfo.txt"))
  out
}
lpqs_cluster <- function(cores,env,out,prefix="^(lpqs_|lpqp_|btc_|cal_)") {
  available <- parallel::detectCores(); if(is.na(available)) available <- 1L
  cores <- max(1L,min(as.integer(cores),available))
  if(cores==1L) return(NULL)
  cl <- parallel::makePSOCKcluster(cores,outfile=file.path(out,"logs","workers.log"))
  ok <- FALSE; on.exit(if(!ok) parallel::stopCluster(cl))
  parallel::clusterCall(cl,function(lib) .libPaths(lib),.libPaths())
  nm <- ls(env,pattern=prefix)
  nm <- nm[vapply(nm,function(n) is.function(get(n,env)),logical(1))]
  parallel::clusterExport(cl,nm,envir=env)
  ok <- TRUE; cl
}
lpqs_source <- function(path,option,env=parent.frame()) {
  old <- options(setNames(list(FALSE),option)); on.exit(options(old))
  source(path,local=env)
}
