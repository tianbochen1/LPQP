# LPQP

R code for *Power-Dependent Visibility of Serial Dependence in Lp-Quantile Spectra*.

## Requirements

Use R with the standard `parallel` package. The Bitcoin analysis also requires `digest` for SHA-256 checks. No other contributed R packages are required.

```r
install.packages("digest")
```

Keep all R files in the same directory. Parallel computations use PSOCK workers and run on Windows, macOS and Linux. The default is eight workers. Random-number streams are assigned to simulation replications or data windows, independently of worker scheduling.

## Run the analyses

From the extracted directory, run:

```r
source("00_run_all.R")
```

The default sequence is the latent-state simulation, the independent null calculation, bootstrap calibration, DK1, and BTCUSDT. Full simulation settings are used. Edit `SETTINGS` in `00_run_all.R` to select tasks, change the worker count, or supply local data. Settings can also be supplied through an R option:

```r
options(lpqp.run = list(TASKS = c("simulation", "null_check"), CORES = 8L))
source("00_run_all.R")
options(lpqp.run = NULL)
```

Command-line examples:

```sh
Rscript 00_run_all.R --tasks=simulation,null_check --cores=8
Rscript 00_run_all.R --tasks=calibration --cores=8
Rscript 00_run_all.R --tasks=dk1,btc --cores=8
```

| File | Purpose |
|---|---|
| `00_run_all.R` | Select and run analyses; collect manuscript figures |
| `01_run_experiment.R` | Latent-state models, population targets and permutation tests |
| `02_make_figures.R` | Simulation figures and summary tables |
| `03_null_check.R` | Independent null calculation for Model A |
| `04_bootstrap_calibration.R` | Conditionally symmetric GARCH calibration experiments |
| `DK1_LpQP_all_in_one.R` | Hourly DK1 electricity-price analysis |
| `BTCUSDT_LpQP_all_in_one.R` | Five-minute Bitcoin-return analysis |
| `05_make_application_figures.R` | DK1 and BTCUSDT manuscript figures from completed results |
| `lpqp_support.R` | Shared random-number, checkpoint and parallel utilities |

## Default scientific settings

All analyses use the median level and the power grid `c(1, 1.15, 1.25, 1.35, 1.5, 1.75, 2)`.

| Analysis | Settings |
|---|---|
| Latent-state simulations | 66 settings; sample sizes 400, 800 and 1,600; 1,000 replications; 999 common permutations; lag cutoff 8; seed 20260924 |
| Independent null calculation | Model A; sample size 400; state persistence 0; replacement proportion 0.03; 10,000 replications; 999 common permutations; lag cutoff 8; seed 20260925 |
| Bootstrap calibration | Normal or variance-standardized Student t(5) innovations; continuous observations or rounding step 0.02; 2,000 replications per setting; sample size 8,064 with 72 preceding observations; 1,999 bootstrap draws; mean block length 144; lag cutoffs 12 and 72; seed 20260926 |
| DK1 | 2018–2019, with 2017 for calendar adjustment; eight 12-week windows; 999 permutations; lag cutoffs 24 and 168; seed 20260924 |
| BTCUSDT | 2024–2025; twenty-six 28-day windows; 19,999 bootstrap draws; mean block lengths 72, 144 and 288; lag cutoffs 12 and 72; seed 20260924 |

Both Energy and CvM statistics are retained. Each analysis uses nominal level 0.05. For BTCUSDT, Holm adjustment is applied across windows separately for each reported procedure, lag cutoff, statistic and block length. The main analysis uses Energy, lag cutoff 12 and mean block length 144.

## Data

DK1 prices are downloaded from [Energinet's Energi Data Service](https://www.energidataservice.dk/tso-electricity/Elspotprices). The acquisition function also supports the Open Power System Data archive and local CSV input. A compact local DK1 file has columns `utc_timestamp` and `price_eur_mwh` and covers 2017–2019. Energinet and compatible Open Power System Data CSV formats are also supported.

BTCUSDT five-minute closing prices are downloaded from [Binance's public data archive](https://data.binance.vision/). Downloads include the preceding prices needed for returns and lag history. A local CSV or compressed CSV can be supplied with columns `open_time_utc` and `close`, covering the analysis period and at least 73 preceding five-minute closing prices. The complete processed CSV produced by the Bitcoin script is also accepted.

```r
options(lpqp.run = list(
  TASKS = c("dk1", "btc"),
  DK1_LOCAL_CSV = "data/DK1_hourly_2017_2019.csv",
  BTC_LOCAL_CSV = "data/BTCUSDT_5m_2024-01-01_2025-12-31.csv.gz",
  CORES = 8L
))
source("00_run_all.R")
options(lpqp.run = NULL)
```

The archive contains code only. Real data, simulation outputs and checkpoints are created when the corresponding analyses run.

## Outputs and figures

The main entry point writes to `outputs/simulation`, `outputs/null_check`, `outputs/calibration`, `outputs/dk1` and `outputs/btc`. Each analysis saves tabular results, its configuration and session information. The main entry point collects the seven manuscript PDFs in `outputs/frame`.

The main simulation writes `rejection_summary.csv`, `paired_gains.csv` and population-target CSV files. The independent calculation writes `null_verification.csv` and `null_comparison.csv`; when the main simulation summary is available, the two estimates are recorded separately. Bootstrap calibration writes `calibration_summary.csv`, `ties_and_scale.csv` and `calibration_results.rds`.

The Bitcoin analysis writes all tests to `outputs/btc/results/tables/tests_all.csv`, with separate files for rejected windows, rejection counts, simultaneous power comparisons and Monte Carlo precision diagnostics. Its manuscript figure displays power profiles for main-scan rejections and block-length sensitivity, including the two near-threshold windows discussed in the paper.

Completed results can be plotted without repeating simulations or resampling. For the latent-state simulation:

```r
options(lpqp.results_dir = "outputs/simulation")
source("02_make_figures.R")
options(lpqp.results_dir = NULL)
```

For the applications:

```r
options(lpqp.application.figures = list(
  DK1_RDS = "outputs/dk1/results/DK1_LpQP_results.rds",
  BTC_RDS = "outputs/btc/results/BTCUSDT_LpQP_results.rds",
  FIGURE_DIR = "outputs/frame"
))
source("05_make_application_figures.R")
options(lpqp.application.figures = NULL)
```

Set either result path to `NULL` to plot only the other application. Existing completed result files can be supplied by changing these paths.

## Checkpoints

Interrupted calculations can resume with the same numerical settings. Changing the worker count does not change the assigned random-number streams. Code and configuration signatures prevent reuse of incompatible checkpoints. Completed results produced under a different code signature can still be used as plotting inputs.
