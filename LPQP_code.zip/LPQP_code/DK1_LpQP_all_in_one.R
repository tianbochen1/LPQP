CFG <- list(
  OUTPUT_DIR = NULL,
  CORES = 8L,
  B = 999L,
  SEED = 20260924L,
  LEVEL = 0.05,
  TRAIN_YEAR = 2017L,
  ANALYSIS_YEARS = c(2018L, 2019L),
  PRIMARY_YEAR = 2019L,
  WINDOW_WEEKS = 12L,
  P_GRID = c(1, 1.15, 1.25, 1.35, 1.5, 1.75, 2),
  K_GRID = c(24L, 168L),
  PRIMARY_K = 24L,
  SMOOTH_HALF_WIDTH = 2L,
  PLOT_MAX_FREQUENCY = 1/8,
  CALENDAR_TZ = "Europe/Copenhagen",
  LOCAL_CSV = NULL,
  DATA_SOURCE = "auto",
  RESUME = TRUE,
  SAVE_PERMUTATION_STATISTICS = TRUE,
  QUICK = FALSE
)

DK1_CODE_VERSION <- "1.0.0"

dk1_script_dir <- function() {
  f <- unlist(lapply(sys.frames(), function(z) z$ofile), use.names = FALSE)
  if (length(f)) return(dirname(normalizePath(tail(f, 1), mustWork = TRUE)))
  a <- grep("^--file=", commandArgs(FALSE), value = TRUE)
  if (length(a)) return(dirname(normalizePath(sub("^--file=", "", a[1]),
                                             mustWork = TRUE)))
  getwd()
}
DK1_SCRIPT_DIR <- dk1_script_dir()

dk1_message <- function(...) {
  message(format(Sys.time(), "[%H:%M:%S] "), paste0(..., collapse = ""))
}

dk1_write_csv <- function(x, path) {
  utils::write.csv(x, path, row.names = FALSE, na = "", fileEncoding = "UTF-8")
}

dk1_parse_utc <- function(x) {
  x <- sub("Z$", "", gsub("T", " ", as.character(x), fixed = TRUE))
  as.POSIXct(x, format = "%Y-%m-%d %H:%M:%S", tz = "UTC")
}

dk1_url <- function(base, params) {
  paste0(base, "?", paste(paste0(names(params), "=",
    vapply(params, utils::URLencode, character(1), reserved = TRUE)), collapse = "&"))
}

dk1_download <- function(url, destination) {
  old <- options(timeout = max(600, getOption("timeout", 60)))
  on.exit(options(old), add = TRUE)
  tmp <- paste0(destination, ".part")
  on.exit(unlink(tmp), add = TRUE)
  last_error <- "download did not finish"
  for (attempt in 1:3) {
    ans <- tryCatch({
      status <- utils::download.file(url, tmp, mode = "wb", quiet = TRUE,
                                    method = "libcurl")
      if (status != 0 || !file.exists(tmp) || file.info(tmp)$size < 50)
        stop("Empty or incomplete download")
      TRUE
    }, error = function(e) {last_error <<- conditionMessage(e); FALSE})
    if (ans) {
      if (!file.copy(tmp, destination, overwrite = TRUE)) stop("Cannot save download")
      return(invisible(destination))
    }
    if (attempt < 3) Sys.sleep(attempt)
  }
  stop(last_error)
}

dk1_read_prices <- function(path) {
  first <- readLines(path, n = 1L, warn = FALSE, encoding = "UTF-8")
  if (!length(first)) stop("Empty CSV: ", path)
  if (grepl("HourUTC", first, fixed = TRUE)) {
    d <- if (grepl(";", first, fixed = TRUE)) {
      utils::read.csv2(path, stringsAsFactors = FALSE, check.names = FALSE,
                      fileEncoding = "UTF-8-BOM")
    } else {
      utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE,
                     fileEncoding = "UTF-8-BOM")
    }
    if (!all(c("HourUTC", "SpotPriceEUR") %in% names(d)))
      stop("Energinet CSV must contain HourUTC and SpotPriceEUR")
    if ("PriceArea" %in% names(d)) d <- d[d$PriceArea == "DK1", , drop = FALSE]
    value <- suppressWarnings(as.numeric(gsub(",", ".", as.character(d$SpotPriceEUR),
                                               fixed = TRUE)))
    return(data.frame(time = dk1_parse_utc(d$HourUTC), price = value))
  }
  nm <- names(utils::read.csv(path, nrows = 0L, check.names = FALSE,
                             fileEncoding = "UTF-8-BOM"))
  value_name <- if ("price_eur_mwh" %in% nm) "price_eur_mwh" else "DK_1_price_day_ahead"
  needed <- c("utc_timestamp", value_name)
  if (!all(needed %in% nm)) stop("Unrecognized CSV columns in ", path)
  cc <- rep("NULL", length(nm))
  cc[match(needed, nm)] <- c("character", "numeric")
  d <- utils::read.csv(path, colClasses = cc, check.names = FALSE,
                       fileEncoding = "UTF-8-BOM", na.strings = c("", "NA", "null"))
  data.frame(time = dk1_parse_utc(d$utc_timestamp), price = d[[value_name]])
}

dk1_validate_prices <- function(d, years) {
  if (!nrow(d) || anyNA(d$time)) stop("Missing or unparseable UTC timestamps")
  lo <- as.POSIXct(sprintf("%d-01-01", min(years)), tz = "UTC")
  hi <- as.POSIXct(sprintf("%d-01-01", max(years) + 1L), tz = "UTC")
  d <- d[d$time >= lo & d$time < hi, , drop = FALSE]
  if (!nrow(d)) stop("Source contains no data in the requested years")
  if (any(abs(as.numeric(d$time) %% 3600) > 0.01))
    stop("Input is not hourly data on the UTC hour grid")
  duplicates <- sum(duplicated(d$time))
  if (duplicates) {
    g <- split(seq_len(nrow(d)), as.numeric(d$time))
    ix <- vapply(g, function(j) {
      v <- unique(d$price[j][is.finite(d$price[j])])
      if (length(v) > 1L) stop("Conflicting prices at a duplicate UTC timestamp")
      finite <- j[is.finite(d$price[j])]
      if (length(finite)) finite[1] else j[1]
    }, integer(1))
    d <- d[ix, , drop = FALSE]
  }
  grid <- data.frame(time = seq(lo, hi - 3600, by = "hour"))
  grid$price <- d$price[match(grid$time, d$time)]
  grid$price[!is.finite(grid$price)] <- NA_real_
  yr <- as.integer(format(grid$time, "%Y", tz = "UTC"))
  for (y in years) if (sum(is.finite(grid$price[yr == y])) == 0L)
    stop("No finite prices available for year ", y)
  attr(grid, "duplicate_rows_removed") <- duplicates
  grid
}

dk1_acquire <- function(cfg, dirs) {
  years <- sort(unique(c(cfg$TRAIN_YEAR, cfg$ANALYSIS_YEARS)))
  cache <- file.path(dirs$data, sprintf("DK1_hourly_%d_%d.csv", min(years), max(years)))
  if (!is.null(cfg$LOCAL_CSV)) {
    d <- dk1_validate_prices(dk1_read_prices(cfg$LOCAL_CSV), years)
    attr(d, "source") <- paste("Local file:", normalizePath(cfg$LOCAL_CSV))
    return(d)
  }
  if (file.exists(cache)) {
    dk1_message("Using cached hourly prices: ", basename(cache))
    d <- dk1_validate_prices(dk1_read_prices(cache), years)
    note <- paste0(cache, ".source.txt")
    attr(d, "source") <- if (file.exists(note)) paste(readLines(note, warn = FALSE),
                                                       collapse = "\n") else cache
    return(d)
  }
  sources <- switch(cfg$DATA_SOURCE, auto = c("energinet", "opsd"),
                    energinet = "energinet", opsd = "opsd", stop("Invalid DATA_SOURCE"))
  failures <- character()
  for (s in sources) {
    ans <- tryCatch({
      if (s == "energinet") {

        url <- dk1_url("https://api.energidataservice.dk/dataset/Elspotprices/download",
          list(format = "csv", start = sprintf("%d-12-31", min(years) - 1L),
               end = sprintf("%d-01-02", max(years) + 1L),
               filter = '{"PriceArea":["DK1"]}', sort = "HourUTC asc",
               columns = "HourUTC,PriceArea,SpotPriceEUR", limit = "1000000"))
        raw_file <- file.path(dirs$data, "energinet_DK1_download.csv")
      } else {
        url <- paste0("https://data.open-power-system-data.org/time_series/2020-10-06/",
                      "time_series_60min_singleindex.csv")
        raw_file <- file.path(dirs$data, "OPSD_2020-10-06_hourly.csv")
      }
      dk1_message("Downloading ", s, " data", if (s == "opsd") " (about 124 MB)" else "")
      dk1_download(url, raw_file)
      d <- dk1_validate_prices(dk1_read_prices(raw_file), years)
      note <- c(paste("Provider:", s), paste("URL:", url),
                paste("Downloaded UTC:", format(Sys.time(), tz = "UTC", usetz = TRUE)),
                "Variable: DK1 day-ahead spot price, EUR/MWh.",
                "Negative prices retained. Missing hours are not interpolated.")
      dk1_write_csv(data.frame(utc_timestamp = format(d$time, "%Y-%m-%dT%H:%M:%SZ", tz = "UTC"),
                              price_eur_mwh = d$price), cache)
      writeLines(note, paste0(cache, ".source.txt"))
      attr(d, "source") <- paste(note, collapse = "\n")
      d
    }, error = function(e) {
      failures <<- c(failures, paste(s, conditionMessage(e), sep = ": "))
      dk1_message("Source failed: ", tail(failures, 1))
      NULL
    })
    if (!is.null(ans)) return(ans)
  }
  stop("Data download failed. Set LOCAL_CSV to a downloaded CSV.\n",
       paste(failures, collapse = "\n"))
}

dk1_calendar <- function(time, tz) {
  t <- as.POSIXlt(time, tz = tz)
  as.integer(((t$wday + 6L) %% 7L) * 24L + t$hour + 1L)
}

dk1_seasonality <- function(data, cfg) {
  train <- as.integer(format(data$time, "%Y", tz = "UTC")) == cfg$TRAIN_YEAR
  how <- dk1_calendar(data$time, cfg$CALENDAR_TZ)
  good <- train & is.finite(data$price)
  n <- tabulate(how[good], nbins = 168L)
  if (any(n < 10L)) stop("Training year has fewer than 10 observations in a calendar cell")
  med <- vapply(1:168, function(j) stats::median(data$price[good & how == j]), numeric(1))
  list(adjusted = data$price - med[how],
       table = data.frame(hour_of_week = 1:168, weekday = rep(1:7, each = 24),
                          hour = rep(0:23, 7), training_n = n, median_eur_mwh = med))
}

dk1_windows <- function(data, cfg) {
  n <- as.integer(cfg$WINDOW_WEEKS * 7L * 24L)
  rows <- list()
  for (yr in cfg$ANALYSIS_YEARS) {
    ix <- which(as.integer(format(data$time, "%Y", tz = "UTC")) == yr)
    chunks <- split(ix, ceiling(seq_along(ix)/n))
    for (w in seq_along(chunks)) {
      j <- chunks[[w]]
      status <- if (length(j) < n) "unused_year_end_tail" else if (anyNA(data$price[j]))
        "skipped_missing_hours" else "included"
      rows[[length(rows) + 1L]] <- data.frame(
        window_id = sprintf("%d_W%02d", yr, w), year = yr,
        role = if (yr == cfg$PRIMARY_YEAR) "primary_year" else "replication_year",
        start_utc = format(data$time[min(j)], "%Y-%m-%dT%H:%M:%SZ", tz = "UTC"),
        end_utc = format(data$time[max(j)], "%Y-%m-%dT%H:%M:%SZ", tz = "UTC"),
        n = length(j), missing_hours = sum(is.na(data$price[j])),
        first_row = min(j), last_row = max(j), status = status)
    }
  }
  do.call(rbind, rows)
}

dk1_fit_scores <- function(y, powers) {
  stopifnot(length(y) > 2L, all(is.finite(y)))
  anchor <- stats::median(y)
  scale <- stats::mad(y)
  if (!is.finite(scale) || scale <= 0) scale <- stats::sd(y)
  if (!is.finite(scale) || scale <= 0) scale <- 1
  x <- (y - anchor)/scale
  z <- matrix(0, length(y), length(powers))
  mu <- variance <- numeric(length(powers))
  for (j in seq_along(powers)) {
    p <- powers[j]
    m <- if (p == 1) stats::median(x) else if (p == 2) mean(x) else {
      if (min(x) == max(x)) x[1] else
        stats::uniroot(function(a) sum(sign(x - a) * abs(x - a)^(p - 1)),
                       range(x), tol = 1e-11, maxiter = 1000L)$root
    }
    a <- sign(x - m) * abs(x - m)^(p - 1)
    a <- a - mean(a)
    v <- mean(a^2)
    if (v > 0) z[, j] <- a/sqrt(v)
    mu[j] <- anchor + scale*m
    variance[j] <- v * scale^(2*p - 2)
  }
  colnames(z) <- sprintf("p%.2f", powers)
  list(z = z, centers = mu, score_variance = variance)
}

dk1_lag_stats <- function(z, K_grid) {
  n <- nrow(z); d <- ncol(z)
  m <- stats::nextn(2L*n - 1L)
  padded <- rbind(z, matrix(0, m - n, d))
  fz <- stats::mvfft(padded)
  ans <- vector("list", length(K_grid))
  for (j in seq_along(K_grid)) {
    K <- K_grid[j]
    tail_z <- padded
    tail_z[seq_len(K), ] <- 0

    cross <- Re(stats::mvfft(stats::mvfft(tail_z) * Conj(fz), inverse = TRUE))/m
    r <- cross[seq_len(K) + 1L, , drop = FALSE]/(n - K)
    ans[[j]] <- list(K = K, r = r, Energy = (n - K)*colSums(r^2),
                    CvM = (n - K)*colSums(r^2/(seq_len(K)^2)))
  }
  ans
}

dk1_flat_stats <- function(z, K_grid) {
  a <- dk1_lag_stats(z, K_grid)
  unlist(lapply(a, function(q) c(q$Energy, q$CvM)), use.names = FALSE)
}

dk1_rank_calibration <- function(statistics, columns) {
  N <- nrow(statistics)
  u <- apply(statistics, 2L, function(x) rank(-x, ties.method = "max")/N)
  if (!is.matrix(u)) u <- matrix(u, ncol = 1L)
  minimum <- apply(u[, columns, drop = FALSE], 1L, min)
  list(p_value = mean(minimum <= minimum[1]),
       minimum_p = minimum[1], marginal = u[1, ], ranks = u)
}

dk1_permutation <- function(z, cfg) {
  d <- ncol(z)
  map <- do.call(rbind, lapply(cfg$K_GRID, function(K)
    do.call(rbind, lapply(c("Energy", "CvM"), function(s)
      data.frame(K = K, statistic = s, p = cfg$P_GRID)))))
  tab <- matrix(NA_real_, cfg$B + 1L, nrow(map))
  tab[1, ] <- dk1_flat_stats(z, cfg$K_GRID)
  for (b in seq_len(cfg$B)) {
    perm <- sample.int(nrow(z))
    tab[b + 1L, ] <- dk1_flat_stats(z[perm, , drop = FALSE], cfg$K_GRID)
  }
  u <- apply(tab, 2L, function(x) rank(-x, ties.method = "max")/nrow(tab))
  rows <- list()
  for (K in cfg$K_GRID) for (s in c("Energy", "CvM")) {
    ix <- which(map$K == K & map$statistic == s)
    eu <- ix[map$p[ix] %in% c(1, 2)]
    for (j in ix) {
      sd_null <- stats::sd(tab[-1, j])
      rows[[length(rows) + 1L]] <- data.frame(K = K, statistic = s,
        method = "fixed_p", p = map$p[j], observed = tab[1, j],
        null_mean = mean(tab[-1, j]), null_sd = sd_null,
        null_standardized = if (sd_null > 0) (tab[1, j] - mean(tab[-1, j]))/sd_null else NA_real_,
        minimum_marginal_p = u[1, j], p_value = u[1, j])
    }
    for (method in c("endpoint_union", "adaptive_scan")) {
      cols <- if (method == "endpoint_union") eu else ix
      minimum <- apply(u[, cols, drop = FALSE], 1L, min)
      rows[[length(rows) + 1L]] <- data.frame(K = K, statistic = s,
        method = method, p = NA_real_, observed = NA_real_,
        null_mean = NA_real_, null_sd = NA_real_, null_standardized = NA_real_,
        minimum_marginal_p = minimum[1], p_value = mean(minimum <= minimum[1]))
    }
  }

  minimum <- apply(u, 1L, min)
  omnibus <- mean(minimum <= minimum[1])
  list(tests = do.call(rbind, rows), omnibus = omnibus,
       column_map = map,
       statistics = if (cfg$SAVE_PERMUTATION_STATISTICS) tab else NULL)
}

dk1_circular_smooth <- function(a, half_width) {
  if (half_width == 0L) return(a)
  n <- nrow(a)
  out <- matrix(0, n, ncol(a))
  for (s in -half_width:half_width)
    out <- out + a[((seq_len(n) - 1L + s) %% n) + 1L, , drop = FALSE]
  out/(2L*half_width + 1L)
}

dk1_spectra <- function(z, cfg) {
  n <- nrow(z); q <- floor(n/2)
  I <- Mod(stats::mvfft(z))^2/n
  smooth <- dk1_circular_smooth(I, cfg$SMOOTH_HALF_WIDTH)
  idx <- seq_len(q) + 1L
  freq <- seq_len(q)/n
  weight <- rep(1, q)
  if (n %% 2L == 0L) weight[q] <- 0.5
  pos <- I[idx, , drop = FALSE]
  den <- colSums(pos * weight)
  mass <- sweep(pos * weight, 2L, ifelse(den > 0, den, 1), "/")
  cdf <- apply(mass, 2L, cumsum)
  if (any(den == 0)) cdf[, den == 0] <- 2*freq
  bands <- list(weekly = c(1/192, 1/144), daily = c(1/26, 1/22),
                half_daily = c(1/13, 1/11))
  band_rows <- list()
  for (nm in names(bands)) {
    in_band <- which(freq >= bands[[nm]][1] & freq <= bands[[nm]][2])
    if (!length(in_band)) stop("Window too short for the specified bands")
    for (j in seq_along(cfg$P_GRID)) {
      k <- in_band[which.max(smooth[idx[in_band], j])]
      band_rows[[length(band_rows) + 1L]] <- data.frame(
        band = nm, p = cfg$P_GRID[j], lower_frequency = bands[[nm]][1],
        upper_frequency = bands[[nm]][2], fourier_bins = length(in_band),
        mass = if (den[j] > 0) sum(mass[in_band, j]) else NA_real_,
        white_reference_mass = sum(weight[in_band])/sum(weight),
        peak_frequency = if (den[j] > 0) freq[k] else NA_real_,
        peak_period_hours = if (den[j] > 0) 1/freq[k] else NA_real_)
    }
  }
  list(frequency = freq, raw_shape = pos, smooth_shape = smooth[idx, , drop = FALSE],
       cdf = cdf, bands = do.call(rbind, band_rows),
       valid_variance = den > 0)
}

dk1_streams <- function(n, seed) {
  old_kind <- RNGkind()
  had_seed <- exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE)
  if (had_seed) old_seed <- get(".Random.seed", envir = .GlobalEnv)
  on.exit({do.call(RNGkind, as.list(old_kind))
    if (had_seed) assign(".Random.seed", old_seed, envir = .GlobalEnv)
    else if (exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE))
      rm(".Random.seed", envir = .GlobalEnv)}, add = TRUE)
  RNGkind("L'Ecuyer-CMRG")
  set.seed(seed)
  ans <- vector("list", n)
  s <- get(".Random.seed", envir = .GlobalEnv)
  for (i in seq_len(n)) {ans[[i]] <- s; s <- parallel::nextRNGStream(s)}
  ans
}

dk1_analyze_window <- function(job, cfg) {
  meta <- list(version = cfg$CODE_VERSION, p = cfg$P_GRID, K = cfg$K_GRID,
               B = cfg$B, smooth = cfg$SMOOTH_HALF_WIDTH,
               save_permutations = cfg$SAVE_PERMUTATION_STATISTICS,
               stream = job$stream, raw = job$raw, adjusted = job$adjusted)
  if (cfg$RESUME && file.exists(job$cache)) {
    old <- tryCatch(readRDS(job$cache), error = function(e) NULL)
    if (!is.null(old) && identical(old$meta, meta)) {
      message(job$id, ": cached")
      return(old$result)
    }
  }
  RNGkind("L'Ecuyer-CMRG")
  assign(".Random.seed", job$stream, envir = .GlobalEnv)
  raw <- dk1_fit_scores(job$raw, cfg$P_GRID)
  adjusted <- dk1_fit_scores(job$adjusted, cfg$P_GRID)
  stat <- dk1_permutation(raw$z, cfg)
  desc <- lapply(list(raw = raw, calendar_adjusted = adjusted), function(fit) {
    list(spectra = dk1_spectra(fit$z, cfg),
         acf = dk1_lag_stats(fit$z, max(cfg$K_GRID))[[1]]$r,
         fit = data.frame(p = cfg$P_GRID, center = fit$centers,
                          score_variance = fit$score_variance))
  })
  result <- list(window_id = job$id, year = job$year, role = job$role,
                 n = length(job$raw), description = desc, inference = stat)
  saveRDS(list(meta = meta, result = result), job$cache, compress = TRUE)
  message(job$id, ": completed")
  result
}

dk1_plot_spectra <- function(results, cfg, path, variant) {
  grDevices::pdf(path, width = 10, height = 7.4, useDingbats = FALSE)
  on.exit(grDevices::dev.off(), add = TRUE)
  colors <- grDevices::hcl.colors(length(cfg$P_GRID), "Dark 3")
  for (yr in unique(vapply(results, `[[`, integer(1), "year"))) {
    use <- results[vapply(results, `[[`, integer(1), "year") == yr]
    for (start in seq(1, length(use), by = 4)) {
      par(mfrow = c(2, 2), mar = c(3.8, 4.0, 2.3, 1), oma = c(2.7, 0, 1.7, 0))
      page <- use[start:min(start + 3L, length(use))]
      for (r in page) {
        s <- r$description[[variant]]$spectra
        keep <- s$frequency <= cfg$PLOT_MAX_FREQUENCY
        matplot(s$frequency[keep], pmax(s$smooth_shape[keep, , drop = FALSE], 1e-6),
                type = "l", lty = 1, lwd = 1.2, col = colors, log = "y",
                xlab = "Frequency (cycles/hour)", ylab = "Normalized score spectrum",
                main = r$window_id)
        abline(h = 1, col = "grey65", lty = 3)
        abline(v = c(1/168, 1/24, 1/12), col = "grey75", lty = 3)
      }
      if (length(page) < 4L) for (i in seq_len(4L - length(page))) plot.new()
      label <- if (variant == "raw") "Raw prices" else "Calendar-adjusted prices"
      mtext(paste(label, "- common smoothing across powers"), side = 3, outer = TRUE, line = 0.2)
      par(oma = c(0, 0, 0, 0), fig = c(0, 1, 0, 1), new = TRUE, mar = c(0, 0, 0, 0))
      plot(0, 0, type = "n", axes = FALSE, xlab = "", ylab = "", xlim = c(0, 1), ylim = c(0, 1))
      legend("bottom", legend = paste("p =", cfg$P_GRID), col = colors, lty = 1,
             lwd = 1.5, horiz = TRUE, bty = "n", cex = 0.8, inset = 0.008)
    }
  }
}

dk1_plot_heatmaps <- function(results, cfg, path) {
  values <- unlist(lapply(results, function(r) unlist(lapply(r$description, function(d) {
    s <- d$spectra
    log10(pmax(s$smooth_shape[s$frequency <= cfg$PLOT_MAX_FREQUENCY, ], 1e-6))
  }))))
  zlim <- range(values[is.finite(values)])
  if (diff(zlim) == 0) zlim <- zlim + c(-0.1, 0.1)
  cols <- grDevices::hcl.colors(100, "YlOrRd", rev = TRUE)
  grDevices::pdf(path, width = 11, height = 4.7, useDingbats = FALSE)
  on.exit(grDevices::dev.off(), add = TRUE)
  for (r in results) {
    layout(matrix(1:3, nrow = 1), widths = c(1, 1, 0.12))
    for (variant in c("raw", "calendar_adjusted")) {
      par(mar = c(4, 3.8, 3, 1))
      s <- r$description[[variant]]$spectra
      keep <- s$frequency <= cfg$PLOT_MAX_FREQUENCY
      image(s$frequency[keep], cfg$P_GRID,
            log10(pmax(s$smooth_shape[keep, , drop = FALSE], 1e-6)),
            zlim = zlim, col = cols, xlab = "Frequency (cycles/hour)", ylab = "p",
            ylim = range(cfg$P_GRID), main = paste(r$window_id,
              if (variant == "raw") "Raw prices" else "Calendar-adjusted prices"),
            useRaster = FALSE)
      abline(v = c(1/168, 1/24, 1/12), col = "grey40", lty = 3)
    }
    par(mar = c(4, 0, 3, 3.5))
    zz <- seq(zlim[1], zlim[2], length.out = 101)
    plot.new(); plot.window(xlim = c(0, 1), ylim = zlim, xaxs = "i", yaxs = "i")
    rect(0, head(zz, -1), 1, tail(zz, -1), col = cols, border = NA)
    axis(4, las = 1, cex.axis = 0.75); mtext("log10 spectrum", side = 3, cex = 0.75)
  }
}

dk1_plot_bands <- function(bands, cfg, path) {
  years <- sort(unique(bands$year))
  cols <- grDevices::hcl.colors(length(years), "Dark 3")
  grDevices::pdf(path, width = 11, height = 7, useDingbats = FALSE)
  on.exit(grDevices::dev.off(), add = TRUE)
  par(mfrow = c(2, 3), mar = c(4, 4, 2.7, 1), oma = c(0, 0, 1, 0))
  for (v in c("raw", "calendar_adjusted")) for (bn in c("weekly", "daily", "half_daily")) {
    b <- bands[bands$variant == v & bands$band == bn, ]
    yy <- b$mass/b$white_reference_mass
    plot(range(cfg$P_GRID), range(c(1, yy), finite = TRUE), type = "n",
         xlab = "p", ylab = "Band mass / flat-spectrum reference",
         main = paste(if (v == "raw") "Raw" else "Calendar-adjusted",
                      gsub("_", "-", bn)), cex.main = 0.9)
    abline(h = 1, col = "grey65", lty = 3)
    for (j in seq_along(years)) {
      bb <- b[b$year == years[j], ]
      for (w in unique(bb$window_id)) {
        z <- bb[bb$window_id == w, ]; z <- z[order(z$p), ]
        lines(z$p, z$mass/z$white_reference_mass, col = grDevices::adjustcolor(cols[j], 0.3))
      }
      av <- vapply(cfg$P_GRID, function(p) mean((bb$mass/bb$white_reference_mass)[bb$p == p],
                                               na.rm = TRUE), numeric(1))
      lines(cfg$P_GRID, av, col = cols[j], lwd = 2, type = "b", pch = j + 14)
    }
    legend("topright", legend = years, col = cols, lty = 1, pch = seq_along(years) + 14,
           bty = "n", cex = 0.75)
  }
  mtext("Thin lines: windows; thick lines: descriptive within-year averages", outer = TRUE,
        side = 3, cex = 0.85)
}

dk1_collect <- function(results, cfg, dirs) {
  tests <- bands <- fits <- spectra <- acfs <- list()
  primary <- list()
  for (i in seq_along(results)) {
    r <- results[[i]]
    prefix <- data.frame(window_id = r$window_id, year = r$year, role = r$role, n = r$n)
    tests[[i]] <- cbind(prefix, r$inference$tests)
    z <- subset(r$inference$tests, K == cfg$PRIMARY_K & statistic == "Energy" & method == "adaptive_scan")
    eu <- subset(r$inference$tests, K == cfg$PRIMARY_K & statistic == "Energy" & method == "endpoint_union")
    primary[[i]] <- cbind(prefix, primary_K = cfg$PRIMARY_K,
                         adaptive_p_value = z$p_value, endpoint_union_p_value = eu$p_value,
                         omnibus_p_K_statistic_p_value = r$inference$omnibus)
    for (v in names(r$description)) {
      d <- r$description[[v]]
      head <- cbind(prefix, variant = v)
      bands[[length(bands) + 1L]] <- cbind(head, d$spectra$bands)
      fits[[length(fits) + 1L]] <- cbind(head, d$fit)
      for (j in seq_along(cfg$P_GRID)) {
        spectra[[length(spectra) + 1L]] <- cbind(head, p = cfg$P_GRID[j],
          data.frame(frequency_cycles_per_hour = d$spectra$frequency,
                     raw_normalized_spectrum = d$spectra$raw_shape[, j],
                     smoothed_normalized_spectrum = d$spectra$smooth_shape[, j],
                     integrated_spectrum = d$spectra$cdf[, j]))
        acfs[[length(acfs) + 1L]] <- cbind(head, p = cfg$P_GRID[j],
          data.frame(lag_hours = seq_len(nrow(d$acf)), score_acf = d$acf[, j]))
      }
    }
  }
  tests <- do.call(rbind, tests); bands <- do.call(rbind, bands)
  primary <- do.call(rbind, primary)

  primary$adaptive_p_holm_windows <- stats::p.adjust(primary$adaptive_p_value, "holm")
  primary$reject_primary_holm <- primary$adaptive_p_holm_windows <= cfg$LEVEL

  primary$omnibus_p_holm_windows <- stats::p.adjust(primary$omnibus_p_K_statistic_p_value, "holm")
  tests$null_hypothesis <- "exchangeability_of_raw_hourly_prices_within_window"
  tests$p_value_resolution <- 1/(cfg$B + 1L)
  tests$reject_unadjusted <- tests$p_value <= cfg$LEVEL
  dk1_write_csv(tests, file.path(dirs$tables, "permutation_tests_raw.csv"))
  dk1_write_csv(primary, file.path(dirs$tables, "primary_tests.csv"))
  dk1_write_csv(bands, file.path(dirs$tables, "band_mass_by_p.csv"))
  dk1_write_csv(do.call(rbind, fits), file.path(dirs$tables, "fitted_locations.csv"))
  dk1_write_csv(do.call(rbind, spectra), file.path(dirs$tables, "spectra_long.csv"))
  dk1_write_csv(do.call(rbind, acfs), file.path(dirs$tables, "score_acf.csv"))
  list(tests = tests, primary = primary, bands = bands)
}

dk1_run <- function(cfg = CFG) {
  if (cfg$QUICK) cfg$B <- 199L
  cfg$CODE_VERSION <- DK1_CODE_VERSION
  cfg$ANALYSIS_YEARS <- sort(unique(as.integer(cfg$ANALYSIS_YEARS)))
  cfg$P_GRID <- sort(unique(cfg$P_GRID)); cfg$K_GRID <- sort(unique(as.integer(cfg$K_GRID)))
  stopifnot(cfg$B >= 19, cfg$CORES >= 1, cfg$LEVEL > 0, cfg$LEVEL < 1,
            cfg$TRAIN_YEAR < min(cfg$ANALYSIS_YEARS),
            cfg$PRIMARY_YEAR %in% cfg$ANALYSIS_YEARS,
            all(cfg$P_GRID >= 1 & cfg$P_GRID <= 2), all(c(1, 2) %in% cfg$P_GRID),
            length(cfg$P_GRID) >= 3, all(cfg$K_GRID >= 1),
            max(cfg$K_GRID) < cfg$WINDOW_WEEKS*168,
            cfg$PRIMARY_K %in% cfg$K_GRID,
            cfg$SMOOTH_HALF_WIDTH >= 0,
            cfg$CALENDAR_TZ %in% OlsonNames())
  base <- if (is.null(cfg$OUTPUT_DIR)) DK1_SCRIPT_DIR else cfg$OUTPUT_DIR
  dir.create(base, recursive = TRUE, showWarnings = FALSE)
  base <- normalizePath(base, winslash = "/", mustWork = TRUE)
  root <- file.path(base, if (cfg$QUICK) "results_quick" else "results")
  dirs <- list(data = file.path(base, "data"), root = root, tables = file.path(root, "tables"),
               frame = file.path(root, "frame"), checkpoints = file.path(root, "checkpoints"))
  for (d in dirs) dir.create(d, recursive = TRUE, showWarnings = FALSE)
  dk1_message("DK1 Lp score analysis; B = ", cfg$B, "; requested cores = ", cfg$CORES)
  data <- dk1_acquire(cfg, dirs)
  seasonality <- dk1_seasonality(data, cfg)
  data$calendar_adjusted <- seasonality$adjusted
  dk1_write_csv(seasonality$table, file.path(dirs$tables, "training_calendar_medians.csv"))
  yr <- as.integer(format(data$time, "%Y", tz = "UTC"))
  quality <- do.call(rbind, lapply(sort(unique(yr)), function(y) {
    a <- data$price[yr == y]
    data.frame(year = y, expected_hours = length(a), observed_hours = sum(is.finite(a)),
               missing_hours = sum(!is.finite(a)), negative_prices = sum(a < 0, na.rm = TRUE),
               median_eur_mwh = median(a, na.rm = TRUE), min_eur_mwh = min(a, na.rm = TRUE),
               max_eur_mwh = max(a, na.rm = TRUE))
  }))
  dk1_write_csv(quality, file.path(dirs$tables, "data_quality.csv"))
  missing <- data[is.na(data$price), "time", drop = FALSE]
  names(missing) <- "missing_utc"
  dk1_write_csv(missing, file.path(dirs$tables, "missing_hours.csv"))
  plan <- dk1_windows(data, cfg)
  if (cfg$QUICK) {
    incl <- which(plan$status == "included")
    if (length(incl) > 1L) plan$status[incl[-1]] <- "not_run_quick_mode"
  }
  dk1_write_csv(plan, file.path(dirs$tables, "window_plan.csv"))
  use <- which(plan$status == "included")
  if (!length(use)) stop("No complete analysis windows; inspect window_plan.csv")
  streams <- dk1_streams(nrow(plan), cfg$SEED)
  tasks <- lapply(use, function(i) {
    ix <- plan$first_row[i]:plan$last_row[i]
    list(id = plan$window_id[i], year = plan$year[i], role = plan$role[i],
         raw = data$price[ix], adjusted = data$calendar_adjusted[ix], stream = streams[[i]],
         cache = file.path(dirs$checkpoints, paste0(plan$window_id[i], ".rds")))
  })
  cores <- parallel::detectCores(logical = FALSE)
  if (is.na(cores)) cores <- 1L
  workers <- min(as.integer(cfg$CORES), cores, length(tasks))
  dk1_message(length(tasks), " complete windows; ", workers, " parallel workers")
  t0 <- proc.time()[3]
  if (workers > 1L) {
    cluster <- parallel::makePSOCKcluster(workers,
      outfile = file.path(dirs$root, "parallel_workers.log"))
    on.exit(parallel::stopCluster(cluster), add = TRUE)
    exports <- c("dk1_fit_scores", "dk1_lag_stats", "dk1_flat_stats", "dk1_permutation",
                 "dk1_circular_smooth", "dk1_spectra", "dk1_analyze_window")
    parallel::clusterExport(cluster, exports, envir = environment(dk1_run))

    results <- parallel::parLapplyLB(cluster, tasks, dk1_analyze_window, cfg = cfg)
  } else results <- lapply(tasks, dk1_analyze_window, cfg = cfg)
  tab <- dk1_collect(results, cfg, dirs)
  dk1_message("Writing figures and RData")
  grDevices::pdf(file.path(dirs$frame, "01_price_series.pdf"), width = 11, height = 6.5,
                 useDingbats = FALSE)
  par(mfrow = c(2, 1), mar = c(3, 4, 2, 1))
  plot(data$time, data$price, type = "l", col = "#314D68", xlab = "UTC date",
       ylab = "EUR/MWh", main = "DK1 hourly day-ahead price")
  abline(h = 0, col = "grey65", lty = 3)
  plot(data$time, data$calendar_adjusted, type = "l", col = "#87603B", xlab = "UTC date",
       ylab = "EUR/MWh", main = paste("Calendar adjustment fitted using", cfg$TRAIN_YEAR))
  abline(h = 0, col = "grey65", lty = 3)
  grDevices::dev.off()
  dk1_plot_spectra(results, cfg, file.path(dirs$frame, "02_spectra_raw.pdf"), "raw")
  dk1_plot_spectra(results, cfg, file.path(dirs$frame, "03_spectra_calendar_adjusted.pdf"), "calendar_adjusted")
  dk1_plot_heatmaps(results, cfg, file.path(dirs$frame, "04_p_frequency_maps.pdf"))
  dk1_plot_bands(tab$bands, cfg, file.path(dirs$frame, "05_band_mass_by_p.pdf"))
  save(results, cfg, data, plan, seasonality, tab,
       file = file.path(dirs$root, "DK1_LpQP_results.RData"), compress = "xz")
  saveRDS(list(results = results, config = cfg, window_plan = plan,
               seasonality = seasonality$table, tables = tab),
          file.path(dirs$root, "DK1_LpQP_results.rds"), compress = "xz")
  writeLines(capture.output(sessionInfo()), file.path(dirs$root, "sessionInfo.txt"))
  writeLines(capture.output(dput(cfg)), file.path(dirs$root, "configuration.R"))
  dk1_message("Completed in ", round(proc.time()[3] - t0, 1), " seconds. Output: ", dirs$root)
  print(tab$primary, row.names = FALSE)
  invisible(list(results = results, config = cfg, paths = dirs, tables = tab))
}

if (!identical(getOption("dk1.autorun"), FALSE)) {
  args <- commandArgs(trailingOnly = TRUE)
  if ("--quick" %in% args) CFG$QUICK <- TRUE
  for (a in args) {
    if (grepl("^--cores=", a)) CFG$CORES <- as.integer(sub("^--cores=", "", a))
    if (grepl("^--B=", a)) CFG$B <- as.integer(sub("^--B=", "", a))
  }
  CFG <- modifyList(CFG,getOption("dk1.config",list()))
  DK1_RESULT <- dk1_run(CFG)
}
