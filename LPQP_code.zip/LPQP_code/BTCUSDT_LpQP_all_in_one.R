CFG <- list(
  SYMBOL = "BTCUSDT",
  START_DATE = "2024-01-01",
  END_DATE = "2025-12-31",
  DISCOVERY_YEAR = 2024L,
  VALIDATION_YEAR = 2025L,
  WINDOW_DAYS = 28L,
  ALPHA = 0.5,
  P_GRID = c(1, 1.15, 1.25, 1.35, 1.5, 1.75, 2),
  K_GRID = c(12L, 72L),
  PRIMARY_K = 12L,
  BLOCK_LENGTHS = c(72L, 144L, 288L),
  PRIMARY_BLOCK = 144L,
  B = 19999L,
  MC_BATCHES = 10L,
  EXPECTED_WINDOWS = 26L,
  DATA_CACHE_DIR = NULL,
  LEVEL = 0.05,
  CORES = 8L,
  SEED = 20260924L,
  ROOT_TOL = 1e-10,
  SMOOTH_HALF_WIDTH = 5L,
  PLOT_MAX_CYCLES_PER_HOUR = 1,
  OUTPUT_DIR = NULL,
  LOCAL_CSV = NULL,
  ALLOW_DOWNLOAD = TRUE,
  VERIFY_SHA256 = TRUE,
  INSTALL_MISSING = TRUE,
  CRAN_REPO = "https://cloud.r-project.org",
  DOWNLOAD_TIMEOUT = 120L,
  DOWNLOAD_RETRIES = 3L,
  RESUME = TRUE,
  CHECKPOINT_EVERY = 100L,
  SAVE_BOOTSTRAP_STATISTICS = TRUE,
  SAVE_RDATA = TRUE,
  MAKE_PLOTS = TRUE,
  QUICK = FALSE,
  QUICK_B = 99L,
  QUICK_WINDOWS = 2L,
  CODE_VERSION = "2.0.0"
)

btc_script_path <- function() {
  f <- Filter(Negate(is.null), lapply(sys.frames(), function(x) x$ofile))
  if (length(f)) return(normalizePath(f[[length(f)]], winslash="/", mustWork=TRUE))
  a <- grep("^--file=", commandArgs(FALSE), value=TRUE)
  if (length(a)) return(normalizePath(sub("^--file=", "", a[1]), winslash="/", mustWork=TRUE))
  NA_character_
}
BTC_SCRIPT_PATH <- btc_script_path()
btc_msg <- function(...) cat(format(Sys.time(), "%H:%M:%S"), " ", ..., "\n", sep="")
btc_utc <- function(x) as.POSIXct(x, origin="1970-01-01", tz="UTC")
btc_stamp <- function(x) format(btc_utc(x), "%Y-%m-%dT%H:%M:%SZ", tz="UTC")
btc_numdate <- function(x) as.numeric(as.POSIXct(x, tz="UTC"))
btc_write_csv <- function(x, file) utils::write.csv(x, file, row.names=FALSE, na="", fileEncoding="UTF-8")
btc_atomic_rds <- function(x, path, compress=FALSE) {
  tmp <- paste0(path, ".tmp-", Sys.getpid())
  saveRDS(x, tmp, compress=compress)
  if (!file.rename(tmp, path)) {
    if (!file.copy(tmp, path, overwrite=TRUE)) stop("Cannot write checkpoint: ", path)
    unlink(tmp)
  }
  invisible(path)
}
btc_require <- function(cfg) {
  if (!requireNamespace("digest", quietly=TRUE) && cfg$INSTALL_MISSING)
    utils::install.packages("digest", repos=cfg$CRAN_REPO)
  if (!requireNamespace("digest", quietly=TRUE))
    stop("Package digest is required. Run install.packages('digest'), then rerun.")
}
btc_hash <- function(x) digest::digest(x, algo="sha256")

btc_download <- function(url, path, cfg) {
  if (file.exists(path) && file.info(path)$size > 0) return(invisible(path))
  if (!cfg$ALLOW_DOWNLOAD) stop("Missing cached download: ", path)
  err <- ""
  for (attempt in seq_len(cfg$DOWNLOAD_RETRIES)) {
    tmp <- paste0(path, ".part")
    ok <- tryCatch({
      status <- utils::download.file(url, tmp, mode="wb", quiet=TRUE,
                                     method="libcurl")
      if (status != 0L || !file.exists(tmp) || file.info(tmp)$size == 0)
        stop("Empty or incomplete download")
      TRUE
    }, error=function(e) { err <<- conditionMessage(e); FALSE })
    if (ok) {
      if (!file.rename(tmp, path)) {
        if (!file.copy(tmp, path, overwrite=TRUE)) stop("Cannot save ", path)
        unlink(tmp)
      }
      return(invisible(path))
    }
    unlink(tmp)
    if (attempt < cfg$DOWNLOAD_RETRIES) Sys.sleep(min(attempt, 3))
  }
  stop("Download failed: ", url, "\n", err,
       "\nDownload this file manually to: ", path,
       "\nOr set LOCAL_CSV to a local close-price file.")
}

btc_seconds <- function(x) {
  x <- as.numeric(x)

  div <- ifelse(abs(x) >= 1e14, 1e6, ifelse(abs(x) >= 1e11, 1e3, 1))
  z <- x/div
  if (any(!is.finite(z))) stop("Invalid kline timestamp")
  if (any(abs(z/300 - round(z/300)) > 1e-7)) stop("Klines are not on the UTC five-minute grid")
  round(z)
}

btc_read_zip <- function(path) {
  li <- utils::unzip(path, list=TRUE)
  member <- li$Name[grepl("\\.csv$", li$Name, ignore.case=TRUE)]
  if (length(member) != 1L) stop("Expected exactly one CSV in ", path)
  tmp <- tempfile("btc_klines_")
  dir.create(tmp)
  on.exit(unlink(tmp,recursive=TRUE),add=TRUE)
  utils::unzip(path,files=member,exdir=tmp,junkpaths=TRUE)
  d <- utils::read.csv(file.path(tmp,basename(member)),header=FALSE,
                      colClasses="character",stringsAsFactors=FALSE)
  if (ncol(d) < 9L) stop("Unexpected Binance kline columns: ", path)
  if (is.na(suppressWarnings(as.numeric(d[1,1])))) d <- d[-1,,drop=FALSE]
  out <- data.frame(open_sec=btc_seconds(d[[1]]), close=as.numeric(d[[5]]),
                    volume=as.numeric(d[[6]]), trades=as.numeric(d[[9]]))
  if (!nrow(out) || any(!is.finite(out$close) | out$close <= 0)) stop("Invalid close price: ", path)
  if (anyDuplicated(out$open_sec)) stop("Duplicate timestamp inside ", path)
  out[order(out$open_sec), ]
}

btc_archive <- function(key, type, cfg, dirs) {
  name <- paste0(cfg$SYMBOL, "-5m-", key, ".zip")
  url <- paste0("https://data.binance.vision/data/spot/", type, "/klines/",
                cfg$SYMBOL, "/5m/", name)
  file <- file.path(dirs$archives, name)
  btc_msg("Archive ", key)
  for (attempt in 1:2) {
    btc_download(url, file, cfg)
    got <- digest::digest(file=file, algo="sha256", serialize=FALSE)
    if (!cfg$VERIFY_SHA256) break
    ck <- paste0(file, ".CHECKSUM")
    btc_download(paste0(url, ".CHECKSUM"), ck, cfg)
    expected <- tolower(strsplit(trimws(readLines(ck, warn=FALSE)[1]), "[[:space:]]+")[[1]][1])
    if (!grepl("^[0-9a-f]{64}$", expected)) stop("Invalid checksum file: ", ck)
    if (identical(got, expected)) break
    if (attempt == 2L || !cfg$ALLOW_DOWNLOAD) stop("SHA256 mismatch: ", file)
    unlink(c(file, ck))
  }
  d <- btc_read_zip(file)
  list(data=d, source=data.frame(archive=name, url=url, sha256=got,
       sha256_verified=cfg$VERIFY_SHA256, rows=nrow(d),
       first_open_utc=btc_stamp(min(d$open_sec)), last_open_utc=btc_stamp(max(d$open_sec))))
}

btc_local_prices <- function(path) {
  d <- utils::read.csv(path, stringsAsFactors=FALSE, check.names=FALSE)
  names(d) <- tolower(sub("^\ufeff", "", names(d)))
  if (!"close" %in% names(d)) stop("LOCAL_CSV must contain a close column")
  if ("open_time_utc" %in% names(d)) {
    sec <- as.numeric(as.POSIXct(d$open_time_utc, format="%Y-%m-%dT%H:%M:%SZ", tz="UTC"))
    sec <- btc_seconds(sec)
  } else if ("open_time" %in% names(d)) {
    sec <- btc_seconds(d$open_time)
  } else stop("LOCAL_CSV needs open_time_utc (ISO UTC) or numeric open_time")
  data.frame(open_sec=sec, close=as.numeric(d$close),
    volume=if ("volume" %in% names(d)) as.numeric(d$volume) else NA_real_,
    trades=if ("trades" %in% names(d)) as.numeric(d$trades) else NA_real_)
}

btc_get_data <- function(cfg, dirs) {
  start <- btc_numdate(cfg$START_DATE)
  end <- btc_numdate(as.character(as.Date(cfg$END_DATE) + 1L))
  pad <- ceiling((max(cfg$K_GRID) + 2L)/288L)
  from <- start-pad*86400
  source_rows <- list()
  if (!is.null(cfg$LOCAL_CSV)) {
    raw <- btc_local_prices(cfg$LOCAL_CSV)
    source_rows[[1]] <- data.frame(archive=basename(cfg$LOCAL_CSV), url="local_file",
      sha256=digest::digest(file=cfg$LOCAL_CSV, algo="sha256", serialize=FALSE),
      sha256_verified=NA, rows=nrow(raw), first_open_utc=btc_stamp(min(raw$open_sec)),
      last_open_utc=btc_stamp(max(raw$open_sec)))
  } else {

    first_month <- as.Date(format(as.Date(cfg$START_DATE), "%Y-%m-01"))
    last_month <- as.Date(format(as.Date(cfg$END_DATE), "%Y-%m-01"))
    months <- format(seq(first_month, last_month, by="month"), "%Y-%m")
    prior_days <- seq(as.Date(btc_utc(from)), as.Date(cfg$START_DATE)-1L, by="day")
    prior_days <- prior_days[format(prior_days, "%Y-%m") < months[1]]
    keys <- c(format(prior_days, "%Y-%m-%d"), months)
    types <- c(rep("daily", length(prior_days)), rep("monthly", length(months)))
    pieces <- vector("list", length(keys))
    for (i in seq_along(keys)) {
      a <- btc_archive(keys[i], types[i], cfg, dirs)
      pieces[[i]] <- a$data; source_rows[[i]] <- a$source
    }
    raw <- do.call(rbind, pieces)
  }
  raw <- raw[raw$open_sec >= from & raw$open_sec < end, ]
  raw <- raw[order(raw$open_sec), ]
  if (any(!is.na(raw$close) & (!is.finite(raw$close) | raw$close <= 0)))
    stop("Nonpositive or infinite observed close prices")
  raw <- raw[!is.na(raw$close),,drop=FALSE]
  if (anyDuplicated(raw$open_sec)) {
    du <- duplicated(raw$open_sec)
    first <- match(raw$open_sec[du], raw$open_sec)
    if (any(raw$close[du] != raw$close[first])) stop("Conflicting duplicate close prices")
    raw <- raw[!du, ]
  }
  grid <- seq(from, end-300, by=300)
  m <- match(grid, raw$open_sec)
  close <- raw$close[m]
  ret <- c(NA_real_, 100*diff(log(close)))

  dat <- data.frame(open_sec=grid, return_sec=grid+300, close=close,
                    return_percent=ret, volume=raw$volume[m], trades=raw$trades[m])
  audit <- data.frame(open_time_utc=btc_stamp(grid), return_time_utc=btc_stamp(grid+300),
                      close=close, return_percent=ret, volume=dat$volume, trades=dat$trades)
  con <- gzfile(file.path(dirs$data, paste0("BTCUSDT_5m_",cfg$START_DATE,"_",cfg$END_DATE,".csv.gz")), "wt")
  utils::write.csv(audit, con, row.names=FALSE, na=""); close(con)
  btc_write_csv(do.call(rbind, source_rows), file.path(dirs$tables, "data_sources.csv"))
  bad <- which(is.na(dat$close))
  gaps <- data.frame(start_open_utc=character(), end_open_utc=character(), missing_bars=integer())
  if (length(bad)) {
    gr <- split(bad, cumsum(c(TRUE, diff(bad) != 1L)))
    gaps <- do.call(rbind, lapply(gr, function(i) data.frame(
      start_open_utc=btc_stamp(grid[min(i)]), end_open_utc=btc_stamp(grid[max(i)]), missing_bars=length(i))))
  }
  btc_write_csv(gaps, file.path(dirs$tables, "missing_intervals.csv"))
  list(data=dat, sources=do.call(rbind, source_rows), gaps=gaps)
}

btc_plan_windows <- function(dat, cfg) {
  start <- btc_numdate(cfg$START_DATE)
  end <- btc_numdate(as.character(as.Date(cfg$END_DATE)+1L))
  years <- seq(as.integer(substr(cfg$START_DATE,1,4)), as.integer(substr(cfg$END_DATE,1,4)))
  n <- cfg$WINDOW_DAYS*288L; K <- max(cfg$K_GRID)
  rows <- list()
  for (yr in years) {
    lo <- max(start, btc_numdate(paste0(yr,"-01-01")))
    hi <- min(end, btc_numdate(paste0(yr+1L,"-01-01")))
    starts <- seq(lo, hi-1, by=n*300)
    for (w in seq_along(starts)) {
      a <- starts[w]; z <- min(a+n*300, hi)
      ix <- which(dat$open_sec >= a & dat$open_sec < z)
      history <- seq.int(min(ix)-K, max(ix))
      bad_history <- min(history)<1L
      missing <- if (bad_history) NA_integer_ else sum(!is.finite(dat$return_percent[history]))
      status <- if (length(ix) < n) "unused_year_end_tail" else if (bad_history || missing > 0L)
        "skipped_missing_returns_or_history" else if (stats::sd(dat$return_percent[ix]) == 0)
        "skipped_constant_returns" else "included"
      role <- if (yr == cfg$DISCOVERY_YEAR) "discovery" else if (yr == cfg$VALIDATION_YEAR)
        "validation" else "additional"
      rows[[length(rows)+1L]] <- data.frame(window_id=sprintf("%d_W%02d",yr,w), year=yr,
        role=role, first_open_utc=btc_stamp(a), last_open_utc=btc_stamp(z-300),
        first_return_utc=btc_stamp(a+300), last_return_utc=btc_stamp(z),
        n=length(ix), history_n=K, missing_returns_with_history=missing,
        first_row=min(ix), last_row=max(ix), status=status)
    }
  }
  out <- do.call(rbind, rows)
  if (cfg$QUICK) {
    inc <- which(out$status == "included")
    if (length(inc)>cfg$QUICK_WINDOWS)
      out$status[inc[-seq_len(cfg$QUICK_WINDOWS)]] <- "not_run_quick_mode"
  }
  out
}

btc_prepare <- function(y_with_history, K) {
  n <- length(y_with_history)-K; core <- seq.int(K+1L, length(y_with_history))
  anchor <- stats::median(y_with_history[core])
  scale <- stats::mad(y_with_history[core])
  if (!is.finite(scale) || scale<=0) scale <- stats::sd(y_with_history[core])
  if (!is.finite(scale) || scale<=0) stop("Constant window")
  x <- (y_with_history-anchor)/scale
  list(x=x, xc=x[core], order=order(x[core]), core=core, n=n, K=K,
       anchor=anchor, scale=scale, nfft=2^ceiling(log2(2*length(x)-1)))
}

btc_weighted_median <- function(x, w, ord) {
  keep <- ord[w[ord] > 0]
  cs <- cumsum(w[keep]); half <- sum(w)/2
  j <- which(cs >= half)[1]
  if (cs[j] == half && j < length(keep)) mean(x[keep[c(j,j+1L)]]) else x[keep[j]]
}

btc_moments <- function(pre, powers, weights=rep(1,pre$n), tol=1e-10, keep_scores=FALSE) {
  stopifnot(length(weights)==pre$n, all(weights>=0), sum(weights)>0)
  total <- sum(weights); J <- length(powers); N <- length(pre$x)
  Z <- matrix(0,N,J); mu <- v <- numeric(J)
  good <- weights>0; xx <- pre$xc[good]; ww <- weights[good]
  for (j in seq_along(powers)) {
    p <- powers[j]
    m <- if (p==1) btc_weighted_median(pre$xc,weights,pre$order) else if (p==2)
      sum(ww*xx)/total else {
        fun <- function(a) sum(ww*sign(xx-a)*abs(xx-a)^(p-1))/total
        if (min(xx)==max(xx)) xx[1] else stats::uniroot(fun,range(xx),tol=tol,maxiter=200L)$root
      }
    z <- sign(pre$x-m)*abs(pre$x-m)^(p-1)
    z <- z-sum(weights*z[pre$core])/total
    vv <- sum(weights*z[pre$core]^2)/total
    if (!is.finite(vv) || vv<=0) stop("Degenerate bootstrap score variance at p=",p)
    Z[,j] <- z/sqrt(vv)
    mu[j] <- pre$anchor+pre$scale*m
    v[j] <- vv*pre$scale^(2*p-2)
  }

  A <- Z
  A[seq_len(pre$K),] <- 0
  A[pre$core,] <- A[pre$core,,drop=FALSE]*weights
  pad <- pre$nfft-N
  AZ <- stats::mvfft(rbind(A,matrix(0,pad,J)))
  FZ <- stats::mvfft(rbind(Z,matrix(0,pad,J)))
  C <- Re(stats::mvfft(AZ*Conj(FZ),inverse=TRUE))/pre$nfft
  acf <- C[seq.int(2L,pre$K+1L),,drop=FALSE]/total
  out <- list(acf=acf, fit=data.frame(p=powers,center=mu,score_variance=v))
  if (keep_scores) out$scores <- Z[pre$core,,drop=FALSE]
  out
}

btc_stationary_weights <- function(n, mean_length) {
  cuts <- c(1L, which(stats::runif(n-1L)<1/mean_length)+1L)
  len <- diff(c(cuts,n+1L))
  starts <- sample.int(n,length(cuts),replace=TRUE)
  ix <- ((rep(starts,len)-1L + seq_len(n)-rep(cuts,len)) %% n)+1L
  tabulate(ix,nbins=n)
}

btc_stat_map <- function(cfg) {
  do.call(rbind,lapply(cfg$K_GRID,function(K) do.call(rbind,lapply(c("Energy","CvM"),
    function(s) data.frame(K=K,statistic=s,p=cfg$P_GRID)))))
}
btc_tail <- function(x, ref) (1+sum(ref>=x))/(length(ref)+1)

btc_calibrate <- function(acf, boot, n, cfg) {
  map <- btc_stat_map(cfg); B <- nrow(boot); Km <- nrow(acf)
  center <- colMeans(boot)
  delta <- sweep(boot,2L,center,"-")
  Q <- matrix(0,B,nrow(map)); obs <- numeric(nrow(map))
  for (j in seq_len(nrow(map))) {
    K <- map$K[j]; ip <- match(map$p[j],cfg$P_GRID)
    ix <- (ip-1L)*Km+seq_len(K)
    w <- if (map$statistic[j]=="Energy") rep(1,K) else 1/seq_len(K)^2
    Q[,j] <- n*as.vector(delta[,ix,drop=FALSE]^2 %*% w)
    obs[j] <- n*sum(acf[seq_len(K),ip]^2*w)
  }
  scale <- colMeans(Q)
  if (any(!is.finite(scale)|scale<=1e-14)) stop("Degenerate bootstrap reference distribution")
  scaled <- sweep(Q,2,scale,"/"); observed_scaled <- obs/scale
  rows <- list()
  for (K in cfg$K_GRID) for (s in c("Energy","CvM")) {
    ix <- which(map$K==K & map$statistic==s)
    ref_all <- apply(scaled[,ix,drop=FALSE],1,max)
    for (j in ix) rows[[length(rows)+1L]] <- data.frame(K=K,statistic=s,
      method="fixed_p",p=map$p[j],observed=obs[j],reference_mean=scale[j],
      scaled_statistic=observed_scaled[j],p_value=btc_tail(obs[j],Q[,j]),
      p_value_adjusted_over_p=btc_tail(observed_scaled[j],ref_all))
    for (method in c("endpoint_union","adaptive_scan")) {
      z <- if (method=="endpoint_union") ix[map$p[ix]%in%c(1,2)] else ix
      rr <- apply(scaled[,z,drop=FALSE],1,max); tt <- max(observed_scaled[z])
      rows[[length(rows)+1L]] <- data.frame(K=K,statistic=s,method=method,p=NA_real_,
        observed=tt,reference_mean=mean(rr),scaled_statistic=tt,
        p_value=btc_tail(tt,rr),p_value_adjusted_over_p=NA_real_)
    }
  }
  tests <- do.call(rbind,rows)
  tests$bootstrap_draws <- B
  tests$tail_exceedances <- as.integer(round(tests$p_value*(B+1)-1))
  tests$tail_exceedances_over_p <- as.integer(round(tests$p_value_adjusted_over_p*(B+1)-1))
  se <- apply(boot,2,stats::sd)
  active <- se>sqrt(.Machine$double.eps)
  ref_max <- if (any(active)) apply(abs(sweep(delta[,active,drop=FALSE],2,se[active],"/")),1,max) else rep(0,B)
  critical <- unname(stats::quantile(ref_max,1-cfg$LEVEL,type=1))
  ci <- data.frame(lag=rep(seq_len(Km),length(cfg$P_GRID)),
    lag_hours=rep(seq_len(Km)/12,length(cfg$P_GRID)),p=rep(cfg$P_GRID,each=Km),
    acf=as.vector(acf),bootstrap_se=se,bootstrap_bias=center-as.vector(acf),
    simultaneous_lower=as.vector(acf)-critical*se,
    simultaneous_upper=as.vector(acf)+critical*se,
    family="all_p_and_lags_within_one_window_and_block_length")
  list(tests=tests,acf_ci=ci,stat_map=map,
       omnibus_p_value=btc_tail(max(observed_scaled),apply(scaled,1,max)),
       reference_statistics=if (cfg$SAVE_BOOTSTRAP_STATISTICS) Q else NULL)
}

btc_spectra <- function(z, cfg) {
  n <- nrow(z); J <- ncol(z)
  I <- Mod(stats::mvfft(z))^2/n
  hw <- min(cfg$SMOOTH_HALF_WIDTH,floor((n-1)/2))
  sm <- matrix(0,n,J)
  for (h in -hw:hw) sm <- sm+I[((seq_len(n)-1L+h)%%n)+1L,,drop=FALSE]
  sm <- sm/(2*hw+1L)
  q <- floor(n/2); idx <- seq_len(q)+1L; wt <- rep(1,q)
  if (n%%2==0) wt[q] <- 0.5
  mass <- I[idx,,drop=FALSE]*wt
  mass <- sweep(mass,2,colSums(mass),"/")
  f <- seq_len(q)*12/n
  bd <- list(daily=c(1/26,1/22),half_daily=c(1/13,1/11),hourly=c(1/1.2,1/0.8))
  rows <- list()
  for (bn in names(bd)) {
    ii <- which(f>=bd[[bn]][1]&f<=bd[[bn]][2])
    for (j in seq_len(J)) rows[[length(rows)+1L]] <- data.frame(band=bn,p=cfg$P_GRID[j],
      lower_cycles_per_hour=bd[[bn]][1],upper_cycles_per_hour=bd[[bn]][2],
      fourier_bins=length(ii),mass=sum(mass[ii,j]),flat_reference_mass=sum(wt[ii])/sum(wt))
  }
  list(frequency_cycles_per_hour=f,smoothed_normalized_spectrum=sm[idx,,drop=FALSE],
       cdf=apply(mass,2,cumsum),bands=do.call(rbind,rows))
}

btc_boot_job <- function(job, cfg) {
  warnings_seen <- character()
  withCallingHandlers(tryCatch({
    if (cfg$RESUME && file.exists(job$complete_file)) {
      old <- readRDS(job$complete_file)
      if (identical(old$key,job$key)) return(list(ok=TRUE,cached=TRUE,result=old$result))
    }
    pre <- btc_prepare(job$y,max(cfg$K_GRID))
    fit <- btc_moments(pre,cfg$P_GRID,tol=cfg$ROOT_TOL,keep_scores=TRUE)
    nr <- pre$K*length(cfg$P_GRID)
    boot <- matrix(NA_real_,cfg$B,nr); done <- 0L
    assign(".Random.seed",job$seed,envir=.GlobalEnv)
    if (cfg$RESUME && file.exists(job$partial_file)) {
      old <- readRDS(job$partial_file)
      if (identical(old$key,job$key)) {
        done <- old$done
        if (done>0) boot[seq_len(done),] <- old$boot
        assign(".Random.seed",old$rng,envir=.GlobalEnv)
      }
    }
    started <- proc.time()[3]
    if (done < cfg$B) for (b in seq.int(done+1L,cfg$B)) {
      w <- btc_stationary_weights(pre$n,job$block_length)
      boot[b,] <- as.vector(btc_moments(pre,cfg$P_GRID,w,cfg$ROOT_TOL)$acf)
      if (b%%cfg$CHECKPOINT_EVERY==0L || b==cfg$B) {
        btc_atomic_rds(list(key=job$key,done=b,boot=boot[seq_len(b),,drop=FALSE],
                           rng=get(".Random.seed",envir=.GlobalEnv)),job$partial_file)
        cat(job$window_id," L=",job$block_length," ",b,"/",cfg$B,"\n",sep="")
        flush.console()
      }
    }
    ans <- btc_calibrate(fit$acf,boot,pre$n,cfg)
    ans$mc_batch_tests <- btc_mc_batches(fit$acf,boot,pre$n,cfg)
    ans$window_id <- job$window_id; ans$year <- job$year; ans$role <- job$role
    ans$block_length <- job$block_length; ans$n <- pre$n
    ans$fit <- fit$fit; ans$acf <- fit$acf
    ans$descriptor <- if (job$block_length==cfg$PRIMARY_BLOCK) btc_spectra(fit$scores,cfg) else NULL
    ans$elapsed_seconds <- unname(proc.time()[3]-started)
    ans$warnings <- unique(warnings_seen)
    btc_atomic_rds(list(key=job$key,result=ans),job$complete_file,compress=TRUE)
    unlink(job$partial_file)
    list(ok=TRUE,cached=FALSE,result=ans)
  },error=function(e) list(ok=FALSE,window_id=job$window_id,block_length=job$block_length,
      message=conditionMessage(e),warnings=unique(warnings_seen))),warning=function(w) {
        warnings_seen <<- c(warnings_seen,conditionMessage(w)); invokeRestart("muffleWarning")
      })
}

btc_collect <- function(results, cfg, dirs) {
  tests <- ci <- bands <- primary <- mc <- list()
  for (i in seq_along(results)) {
    r <- results[[i]]
    meta <- data.frame(window_id=r$window_id,year=r$year,role=r$role,n=r$n,
                       block_length=r$block_length)
    tests[[i]] <- cbind(meta,r$tests)
    if(!is.null(r$mc_batch_tests)) mc[[length(mc)+1L]] <- cbind(meta,r$mc_batch_tests)
    ci[[i]] <- cbind(meta,r$acf_ci)
    if (!is.null(r$descriptor)) bands[[length(bands)+1L]] <- cbind(meta,r$descriptor$bands)
    at <- r$tests$K==cfg$PRIMARY_K & r$tests$statistic=="Energy"
    aa <- r$tests[at & r$tests$method=="adaptive_scan",]
    eu <- r$tests[at & r$tests$method=="endpoint_union",]
    fp <- r$tests[at & r$tests$method=="fixed_p",]
    primary[[i]] <- cbind(meta,primary_K=cfg$PRIMARY_K,
      adaptive_p_value=aa$p_value,endpoint_union_p_value=eu$p_value,
      p1_value=fp$p_value[fp$p==1],p2_value=fp$p_value[fp$p==2],
      omnibus_p_value=r$omnibus_p_value,
      largest_scaled_statistic_p=fp$p[which.max(fp$scaled_statistic)])
  }
  tt <- do.call(rbind,tests); pp <- do.call(rbind,primary)
  cc <- do.call(rbind,ci); bb <- do.call(rbind,bands)
  pp$adaptive_p_holm_windows <- NA_real_
  pp$endpoint_union_p_holm_windows <- NA_real_

  for (L in cfg$BLOCK_LENGTHS) {
    ii <- which(pp$block_length==L)
    pp$adaptive_p_holm_windows[ii] <- p.adjust(pp$adaptive_p_value[ii],"holm")
    pp$endpoint_union_p_holm_windows[ii] <- p.adjust(pp$endpoint_union_p_value[ii],"holm")
  }
  pp$is_primary_block <- pp$block_length==cfg$PRIMARY_BLOCK
  pp$reject_adaptive_holm <- pp$adaptive_p_holm_windows<=cfg$LEVEL
  tt$p_value_fwer_primary_windows_and_p <- NA_real_
  ii <- which(tt$block_length==cfg$PRIMARY_BLOCK & tt$K==cfg$PRIMARY_K &
                tt$statistic=="Energy" & tt$method=="fixed_p")

  nw <- length(unique(tt$window_id[ii]))
  tt$p_value_fwer_primary_windows_and_p[ii] <- pmin(1,nw*tt$p_value_adjusted_over_p[ii])

  pp$interior_only_rejection_screen <- FALSE
  for (i in which(pp$is_primary_block)) {
    d <- tt[ii[tt$window_id[ii]==pp$window_id[i]],]
    p_adj <- d$p_value_fwer_primary_windows_and_p
    pp$interior_only_rejection_screen[i] <-
      any(p_adj[d$p>1 & d$p<2]<=cfg$LEVEL) && all(p_adj[d$p%in%c(1,2)]>cfg$LEVEL)
  }
  tt <- btc_adjust_table(tt,cfg)
  if(length(mc)) {
    mc <- btc_adjust_table(do.call(rbind,mc),cfg,extra="mc_batch")
    btc_write_csv(mc,file.path(dirs$tables,"mc_batch_tests.csv"))
    diag <- btc_mc_summary(tt,mc,cfg)
    btc_write_csv(diag,file.path(dirs$tables,"mc_precision_diagnostics.csv"))
  } else { mc <- NULL; diag <- NULL }
  tt$null_hypothesis <- "score_autocorrelations_zero_at_lags_1_to_K"
  tt$calibration <- "centered_stationary_bootstrap_of_refitted_lag_vectors_asymptotic"
  tt$monte_carlo_resolution <- 1/(cfg$B+1)
  btc_write_csv(tt,file.path(dirs$tables,"tests_all.csv"))
  btc_write_csv(pp[pp$is_primary_block,],file.path(dirs$tables,"primary_tests.csv"))
  btc_write_csv(pp,file.path(dirs$tables,"block_length_sensitivity.csv"))
  btc_write_csv(cc,file.path(dirs$tables,"acf_simultaneous_intervals.csv"))
  if (!is.null(bb)) btc_write_csv(bb,file.path(dirs$tables,"band_mass_by_p.csv"))
  list(tests=tt,primary=pp[pp$is_primary_block,],sensitivity=pp,acf_intervals=cc,bands=bb,
       mc_batch_tests=mc,mc_precision=diag)
}

btc_palette <- function(p) {
  cols <- grDevices::hcl.colors(length(p),"Dark 3")
  cols[p==1] <- "#0072B2"; cols[p==2] <- "#D55E00"
  cols
}

btc_plot_overview <- function(dat,cfg,path) {
  ok <- dat$open_sec>=btc_numdate(cfg$START_DATE)
  d <- dat[ok,]; t <- btc_utc(d$return_sec)

  day <- format(btc_utc(d$open_sec),"%Y-%m-%d",tz="UTC")
  groups <- split(seq_len(nrow(d)),day)
  daily <- do.call(rbind,lapply(groups,function(i) data.frame(
    time=mean(d$return_sec[i]),rv=if (all(is.finite(d$return_percent[i])))
      sqrt(sum(d$return_percent[i]^2)) else NA_real_,
    observed=sum(is.finite(d$return_percent[i])))))
  grDevices::pdf(path,width=10,height=7.5,useDingbats=FALSE)
  on.exit(grDevices::dev.off(),add=TRUE)
  par(mfrow=c(3,1),mar=c(3.6,4.2,2.4,1),mgp=c(2.3,0.6,0))
  plot(t,d$close,type="l",col="#444444",xlab="",ylab="USDT per BTC",main="BTCUSDT spot closing prices")
  plot(t,d$return_percent,type="l",col="#0072B2",xlab="",ylab="Log return (%)",main="Five-minute close-to-close returns")
  plot(btc_utc(daily$time),daily$rv,type="l",col="#D55E00",xlab="UTC date",
       ylab="Daily root sum of squares (%)",main="Daily realized variation (descriptive)")
}

btc_plot_window_profiles <- function(results,tab,cfg,path) {
  rr <- Filter(function(x) x$block_length==cfg$PRIMARY_BLOCK,results)
  grDevices::pdf(path,width=10.5,height=7.5,useDingbats=FALSE)
  on.exit(grDevices::dev.off(),add=TRUE)
  cols <- btc_palette(cfg$P_GRID)
  for (r in rr) {
    par(mfrow=c(2,2),mar=c(4,4.3,2.9,1),oma=c(0,0,2.1,0),mgp=c(2.6,0.7,0))
    sp <- r$descriptor; f <- sp$frequency_cycles_per_hour
    keep <- f<=cfg$PLOT_MAX_CYCLES_PER_HOUR
    matplot(f[keep],sp$smoothed_normalized_spectrum[keep,,drop=FALSE],type="l",
      lty=1,col=cols,xlab="Frequency (cycles/hour)",ylab="Normalized spectrum",
      main="Fitted-score spectra")
    abline(h=1,col="grey50",lty=3)
    legend("topright",legend=paste0("p=",cfg$P_GRID),col=cols,lty=1,bty="n",cex=0.65,ncol=2)
    matplot(f,sp$cdf-f/6,type="l",lty=1,col=cols,xlab="Frequency (cycles/hour)",
      ylab="Empirical CDF minus flat reference",main="Integrated spectral shape")
    abline(h=0,col="grey50",lty=3)
    matplot(seq_len(nrow(r$acf))/12,r$acf,type="l",lty=1,col=cols,xlab="Lag (hours)",
      ylab="Score autocorrelation",main="Autocorrelations at retained lags")
    abline(h=0,col="grey50",lty=3)
    d <- r$tests[r$tests$K==cfg$PRIMARY_K & r$tests$statistic=="Energy" & r$tests$method=="fixed_p",]
    plot(d$p,d$scaled_statistic,type="b",pch=16,col="#333333",xlab="p",
      ylab="Energy / bootstrap reference mean",main=paste0("Energy, K=",cfg$PRIMARY_K),xaxt="n")
    axis(1,at=cfg$P_GRID,labels=cfg$P_GRID,cex.axis=0.75)
    pp <- tab$primary[tab$primary$window_id==r$window_id,]
    mtext(paste(r$window_id,"|",r$role,"| adaptive p (Holm) =",format(pp$adaptive_p_holm_windows,digits=3)),
          side=3,outer=TRUE,line=0.5,cex=0.95)
  }
}

btc_plot_pvalues <- function(tab,cfg,path) {
  d <- tab$tests[tab$tests$block_length==cfg$PRIMARY_BLOCK & tab$tests$K==cfg$PRIMARY_K &
                  tab$tests$statistic=="Energy" & tab$tests$method=="fixed_p",]
  windows <- unique(d$window_id)
  z <- matrix(NA_real_,length(cfg$P_GRID),length(windows))
  for (i in seq_along(windows)) {
    q <- d[d$window_id==windows[i],]
    z[,i] <- -log10(q$p_value_fwer_primary_windows_and_p[match(cfg$P_GRID,q$p)])
  }
  grDevices::pdf(path,width=8,height=max(5,0.26*length(windows)+2),useDingbats=FALSE)
  on.exit(grDevices::dev.off(),add=TRUE)
  par(mar=c(4,7,4,2),mgp=c(2.4,0.6,0))
  y <- seq_along(windows)
  if (length(windows)==1) { z <- cbind(z,z); y <- c(0.75,1.25) }
  image(seq_along(cfg$P_GRID),y,z,col=hcl.colors(100,"YlOrRd",rev=TRUE),
    zlim=c(0,max(2,-log10(1/(cfg$B+1)))),xaxt="n",yaxt="n",xlab="p",ylab="",
    main="Fixed-power tests: max over p, Bonferroni over windows")
  axis(1,at=seq_along(cfg$P_GRID),labels=cfg$P_GRID)
  axis(2,at=seq_along(windows),labels=windows,las=1,cex.axis=0.8)
  for (i in seq_along(windows)) for (j in seq_along(cfg$P_GRID)) {
    v <- d$p_value_fwer_primary_windows_and_p[d$window_id==windows[i] & d$p==cfg$P_GRID[j]]
    text(j,i,formatC(v,format="f",digits=3),cex=0.7,col=if (v<0.02) "white" else "black")
  }
  mtext("Cells show adjusted p-values; darker cells indicate smaller values.",side=3,line=0.2,cex=0.8)
}

btc_plot_sensitivity <- function(tab,cfg,path) {
  d <- tab$sensitivity; win <- unique(d$window_id)
  grDevices::pdf(path,width=10,height=max(5,0.15*length(win)+3),useDingbats=FALSE)
  on.exit(grDevices::dev.off(),add=TRUE)
  par(mar=c(7,4.5,3,1),mgp=c(2.6,0.7,0))
  z <- matrix(NA_real_,length(win),length(cfg$BLOCK_LENGTHS))
  for (j in seq_along(cfg$BLOCK_LENGTHS)) {
    dd <- d[d$block_length==cfg$BLOCK_LENGTHS[j],]
    z[,j] <- dd$adaptive_p_holm_windows[match(win,dd$window_id)]
  }
  z <- matrix(z,nrow=length(win),ncol=length(cfg$BLOCK_LENGTHS))
  ylim <- c(0,max(-log10(z),-log10(cfg$LEVEL),na.rm=TRUE)*1.2)
  matplot(seq_along(win),-log10(z),type="b",lty=seq_along(cfg$BLOCK_LENGTHS),ylim=ylim,
    pch=seq_along(cfg$BLOCK_LENGTHS)+14,col=hcl.colors(length(cfg$BLOCK_LENGTHS),"Dark 3"),
    xaxt="n",xlab="",ylab="-log10 adjusted p-value",main="Adaptive energy test: block-length sensitivity")
  axis(1,at=seq_along(win),labels=win,las=2,cex.axis=0.7)
  abline(h=-log10(cfg$LEVEL),lty=3,col="grey40")
  mtext(paste0("Dotted line: adjusted p = ",cfg$LEVEL),side=3,line=0.2,cex=0.75)
  legend("topright",legend=paste0("Mean block = ",cfg$BLOCK_LENGTHS," bars"),
    col=hcl.colors(length(cfg$BLOCK_LENGTHS),"Dark 3"),lty=seq_along(cfg$BLOCK_LENGTHS),
    pch=seq_along(cfg$BLOCK_LENGTHS)+14,bty="n",cex=0.75)
}

btc_validate_config <- function(cfg) {
  cfg$P_GRID <- sort(unique(cfg$P_GRID)); cfg$K_GRID <- sort(unique(as.integer(cfg$K_GRID)))
  cfg$BLOCK_LENGTHS <- sort(unique(as.integer(cfg$BLOCK_LENGTHS)))
  stopifnot(cfg$SYMBOL=="BTCUSDT",!is.na(as.Date(cfg$START_DATE)),!is.na(as.Date(cfg$END_DATE)),
    as.Date(cfg$START_DATE)<=as.Date(cfg$END_DATE),cfg$WINDOW_DAYS>=1L,cfg$ALPHA==0.5,
    all(cfg$P_GRID>=1 & cfg$P_GRID<=2),all(c(1,2)%in%cfg$P_GRID),length(cfg$P_GRID)>=3,
    all(cfg$K_GRID>=1),max(cfg$K_GRID)<cfg$WINDOW_DAYS*288,
    cfg$PRIMARY_K%in%cfg$K_GRID,all(cfg$BLOCK_LENGTHS>=2),
    max(cfg$BLOCK_LENGTHS)<cfg$WINDOW_DAYS*288/4,
    cfg$PRIMARY_BLOCK%in%cfg$BLOCK_LENGTHS,cfg$B>=19,cfg$CORES>=1,
    cfg$MC_BATCHES>=0,cfg$MC_BATCHES==as.integer(cfg$MC_BATCHES),
    cfg$LEVEL>0 & cfg$LEVEL<1,cfg$CHECKPOINT_EVERY>=1,cfg$PLOT_MAX_CYCLES_PER_HOUR>0,
    cfg$PLOT_MAX_CYCLES_PER_HOUR<=6)
  if (cfg$QUICK) {
    cfg$B <- cfg$QUICK_B; cfg$BLOCK_LENGTHS <- cfg$PRIMARY_BLOCK
    cfg$REQUESTED_END_DATE <- cfg$END_DATE
    cfg$END_DATE <- as.character(min(as.Date(cfg$END_DATE),
      as.Date(cfg$START_DATE)+cfg$WINDOW_DAYS*cfg$QUICK_WINDOWS-1L))
  }

  cfg
}

btc_run <- function(cfg=CFG, script_path=BTC_SCRIPT_PATH) {
  cfg <- modifyList(cfg,getOption("btc.config",list()))
  cfg <- btc_validate_config(cfg)
  btc_require(cfg)
  root <- if (!is.null(cfg$OUTPUT_DIR)) cfg$OUTPUT_DIR else file.path(
    if (!is.na(script_path)) dirname(script_path) else getwd(),"BTCUSDT_LpQP_output")
  dir.create(root,recursive=TRUE,showWarnings=FALSE)
  root <- normalizePath(root,winslash="/",mustWork=TRUE)

  res <- file.path(root,if (cfg$QUICK) "results_quick" else "results")
  dirs <- list(root=root,data=file.path(res,"data"),archives=file.path(root,"data","archives"),
    results=res,tables=file.path(res,"tables"),frame=file.path(res,"frame"),
    checkpoints=file.path(res,"checkpoints"),logs=file.path(res,"logs"))
  for (p in dirs) dir.create(p,recursive=TRUE,showWarnings=FALSE)
  old_options <- options(timeout=max(getOption("timeout",60),cfg$DOWNLOAD_TIMEOUT),
                         warn=1,stringsAsFactors=FALSE)
  on.exit(options(old_options),add=TRUE)
  old_rng <- RNGkind(); had_seed <- exists(".Random.seed",envir=.GlobalEnv,inherits=FALSE)
  if (had_seed) old_seed <- get(".Random.seed",envir=.GlobalEnv)
  on.exit({ do.call(RNGkind,as.list(old_rng)); if (had_seed) assign(".Random.seed",old_seed,.GlobalEnv)
            else if (exists(".Random.seed",.GlobalEnv,inherits=FALSE)) rm(".Random.seed",envir=.GlobalEnv) },add=TRUE)
  btc_msg("BTCUSDT Lp score analysis; B=",cfg$B,"; requested workers=",cfg$CORES)
  tic <- proc.time()[3]
  input <- btc_resolve_input(cfg,dirs,script_path)
  cfg <- input$config; dirs <- input$dirs
  got <- btc_get_data(cfg,dirs); dat <- got$data
  plan <- btc_plan_windows(dat,cfg)
  btc_write_csv(plan,file.path(dirs$tables,"window_plan.csv"))
  selected <- plan[plan$status=="included",,drop=FALSE]
  if (!nrow(selected)) stop("No complete windows. Inspect window_plan.csv and missing_intervals.csv.")
  if(!cfg$QUICK && !is.null(cfg$EXPECTED_WINDOWS) && nrow(selected)!=cfg$EXPECTED_WINDOWS)
    stop("Expected ",cfg$EXPECTED_WINDOWS," complete windows, found ",nrow(selected),
      ". The multiple-testing family must not silently shrink. Inspect window_plan.csv.")
  if (nrow(selected)/(cfg$B+1)>cfg$LEVEL)
    btc_msg("Monte Carlo resolution is too coarse for the window family. Increase B for final inference.")
  summaries <- lapply(seq_len(nrow(selected)),function(i) {
    w<-selected[i,]; y<-dat$return_percent[w$first_row:w$last_row]
    med<-median(y); sdv<-sd(y)
    data.frame(window_id=w$window_id,year=w$year,role=w$role,n=length(y),mean=mean(y),
      median=med,sd=sdv,min=min(y),max=max(y),zero_returns=sum(y==0),
      ties_at_median=sum(y==med),sample_skewness=mean((y-mean(y))^3)/mean((y-mean(y))^2)^1.5,
      sample_kurtosis=mean((y-mean(y))^4)/mean((y-mean(y))^2)^2)
  })
  summary_table <- do.call(rbind,summaries)
  btc_write_csv(summary_table,file.path(dirs$tables,"return_summary.csv"))
  RNGkind("L'Ecuyer-CMRG"); set.seed(cfg$SEED)
  stream <- .Random.seed
  numerical_cfg <- cfg[c("CODE_VERSION","P_GRID","K_GRID","PRIMARY_K","BLOCK_LENGTHS",
    "PRIMARY_BLOCK","B","MC_BATCHES","LEVEL","SEED","ROOT_TOL","SMOOTH_HALF_WIDTH","SAVE_BOOTSTRAP_STATISTICS")]

  fn_names <- c("btc_prepare","btc_weighted_median","btc_moments","btc_stationary_weights",
                "btc_calibrate","btc_mc_batches","btc_spectra","btc_stat_map","btc_tail")
  fn_hash <- btc_hash(lapply(fn_names,function(nm) body(get(nm,mode="function"))))
  jobs <- list()
  for (i in seq_len(nrow(selected))) for (L in cfg$BLOCK_LENGTHS) {
    w <- selected[i,]; ix <- seq.int(w$first_row-max(cfg$K_GRID),w$last_row)
    y <- dat$return_percent[ix]
    key <- btc_hash(list(cfg=numerical_cfg,functions=fn_hash,window=w$window_id,y=y,L=L,seed=stream))
    stem <- paste0(w$window_id,"_L",L,"_",substr(key,1,16))
    jobs[[length(jobs)+1L]] <- list(key=key,window_id=w$window_id,year=w$year,role=w$role,
      block_length=L,y=y,seed=stream,
      complete_file=file.path(dirs$checkpoints,paste0(stem,".rds")),
      partial_file=file.path(dirs$checkpoints,paste0(stem,".partial.rds")))
    stream <- parallel::nextRNGStream(stream)
  }
  available <- parallel::detectCores(logical=TRUE)
  if (is.na(available)) available <- 1L
  cores <- max(1L,min(as.integer(cfg$CORES),available,length(jobs)))
  cl <- NULL
  if (cores>1L) {
    cl <- parallel::makePSOCKcluster(cores,outfile=file.path(dirs$logs,"workers.log"))
    on.exit(if (!is.null(cl)) parallel::stopCluster(cl),add=TRUE)
    parallel::clusterCall(cl,function(lib) .libPaths(lib),.libPaths())
    env <- environment(btc_run)
    exports <- ls(envir=env,pattern="^btc_")
    exports <- exports[vapply(exports,function(nm) is.function(get(nm,envir=env)),logical(1))]
    parallel::clusterExport(cl,exports,envir=env)
  }
  btc_msg(nrow(selected)," complete windows; ",length(jobs)," window/block jobs; ",cores," workers")
  done <- vector("list",length(jobs))
  batches <- split(seq_along(jobs),ceiling(seq_along(jobs)/cores))
  for (b in seq_along(batches)) {
    ix <- batches[[b]]
    btc_msg("Batch ",b,"/",length(batches)," (jobs ",min(ix),"-",max(ix),")")
    done[ix] <- if (is.null(cl)) lapply(jobs[ix],btc_boot_job,cfg=cfg) else
      parallel::parLapplyLB(cl,jobs[ix],btc_boot_job,cfg=cfg)
    for (j in ix) {
      d <- done[[j]]
      if (d$ok) btc_msg(d$result$window_id," L=",d$result$block_length,
                        if (d$cached) " cached" else " completed")
      else btc_msg("FAILED: ",d$window_id," L=",d$block_length," ",d$message)
    }
  }
  if (!is.null(cl)) { parallel::stopCluster(cl); cl <- NULL }
  failed <- Filter(function(z) !z$ok,done)
  errs <- data.frame(window_id=character(),block_length=integer(),message=character())
  if (length(failed)) errs <- do.call(rbind,lapply(failed,function(z)
    data.frame(window_id=z$window_id,block_length=z$block_length,message=z$message)))
  btc_write_csv(errs,file.path(dirs$logs,"errors.csv"))
  if (length(failed)) stop("Some jobs failed. Inspect logs/errors.csv and rerun with RESUME=TRUE. Completed jobs and partial bootstrap draws have been saved.")
  results <- lapply(done,`[[`,"result")
  tabs <- btc_collect(results,cfg,dirs)
  btc_paper_tables(tabs,plan,cfg,dirs)
  if (cfg$MAKE_PLOTS) {
    btc_plot_overview(dat,cfg,file.path(dirs$frame,"01_prices_returns.pdf"))
    btc_plot_window_profiles(results,tabs,cfg,file.path(dirs$frame,"02_window_profiles.pdf"))
    btc_plot_pvalues(tabs,cfg,file.path(dirs$frame,"03_fixed_power_pvalues.pdf"))
    btc_plot_sensitivity(tabs,cfg,file.path(dirs$frame,"04_block_length_sensitivity.pdf"))
    btc_plot_paper(tabs,cfg,file.path(dirs$frame,"btc_profiles.pdf"))
  }
  interpretation <- c(
    "The null is zero score autocorrelations at the retained lags.",
    "The stationary bootstrap refits locations and centers the bootstrap autocorrelations.",
    "Holm adjustment is applied separately across windows for each power or joint procedure, lag cutoff and block length.",
    "The simultaneous fixed-power family uses the within-window maximum followed by Bonferroni adjustment across windows.",
    "Monte Carlo batch standard errors describe approximate numerical precision conditional on the data.",
    "Frequency-domain summaries are descriptive.")
  writeLines(interpretation,file.path(dirs$results,"INTERPRETATION.txt"))
  writeLines(capture.output(utils::sessionInfo()),file.path(dirs$results,"sessionInfo.txt"))
  ans <- list(results=results,config=cfg,window_plan=plan,return_summary=summary_table,
              data_sources=got$sources,gaps=got$gaps,tables=tabs,interpretation=interpretation,
              elapsed_seconds=unname(proc.time()[3]-tic))
  btc_atomic_rds(ans,file.path(dirs$results,"BTCUSDT_LpQP_results.rds"),compress="xz")
  if (cfg$SAVE_RDATA) {
    BTC_RESULT <- ans
    save(BTC_RESULT,file=file.path(dirs$results,"BTCUSDT_LpQP_results.RData"),compress="xz")
  }
  btc_msg("Finished. Results: ",dirs$results)
  print(tabs$primary[,c("window_id","role","adaptive_p_value","adaptive_p_holm_windows",
                       "p1_value","p2_value","interior_only_rejection_screen")],row.names=FALSE)
  invisible(ans)
}

btc_resolve_input <- function(cfg,dirs,script_path) {
  base <- if(!is.na(script_path)) dirname(script_path) else getwd()
  if(!is.null(cfg$DATA_CACHE_DIR) && !dir.exists(cfg$DATA_CACHE_DIR))
    stop("DATA_CACHE_DIR does not exist: ",cfg$DATA_CACHE_DIR)
  candidates <- unique(c(cfg$DATA_CACHE_DIR,file.path(dirs$root,"data"),
    file.path(base,"data"),file.path(base,"BTCUSDT_LpQP_output","data"),
    file.path(dirname(base),"BTCUSDT_LpQP_output","data")))
  candidates <- candidates[dir.exists(candidates)]
  if(!is.null(cfg$LOCAL_CSV)) {
    if(!file.exists(cfg$LOCAL_CSV)) stop("LOCAL_CSV does not exist: ",cfg$LOCAL_CSV)
  } else {

    required_end <- if(is.null(cfg$REQUESTED_END_DATE)) cfg$END_DATE else cfg$REQUESTED_END_DATE
    exact <- paste0("BTCUSDT_5m_",cfg$START_DATE,"_",required_end,".csv.gz")
    files <- file.path(candidates,exact); files <- files[file.exists(files)]
    if(length(files)) cfg$LOCAL_CSV <- files[1]
  }
  if(is.null(cfg$LOCAL_CSV)) {
    archives <- file.path(candidates,"archives")
    present <- archives[dir.exists(archives)]
    if(length(present)) {
      count <- vapply(present,function(p) length(list.files(p,pattern="\\.zip$")),integer(1))
      dirs$archives <- present[which.max(count)]
    }
  }
  if(!is.null(cfg$LOCAL_CSV)) btc_msg("Using local close prices: ",cfg$LOCAL_CSV)
  list(config=cfg,dirs=dirs)
}

btc_mc_batches <- function(acf,boot,n,cfg) {
  m <- min(as.integer(cfg$MC_BATCHES),floor(nrow(boot)/99L))
  if(m<2L) return(NULL)
  group <- rep(seq_len(m),length.out=nrow(boot))
  small <- cfg; small$SAVE_BOOTSTRAP_STATISTICS <- FALSE
  do.call(rbind,lapply(seq_len(m),function(i) {
    z <- btc_calibrate(acf,boot[group==i,,drop=FALSE],n,small)$tests
    cbind(mc_batch=i,z)
  }))
}

btc_adjust_table <- function(tt,cfg,extra=character()) {
  fields <- c("block_length","K","statistic","method",extra)
  key <- do.call(paste,c(tt[fields],list(ifelse(is.na(tt$p),"joint",sprintf("%.8f",tt$p)),sep="|")))
  tt$p_value_holm_windows <- NA_real_; tt$comparison_windows <- NA_integer_
  for(ix in split(seq_len(nrow(tt)),key)) {
    if(anyDuplicated(tt$window_id[ix])) stop("Duplicate window in a comparison family")
    tt$p_value_holm_windows[ix] <- p.adjust(tt$p_value[ix],"holm")
    tt$comparison_windows[ix] <- length(ix)
  }
  tt$reject_holm_windows <- tt$p_value_holm_windows<=cfg$LEVEL
  tt
}

btc_mc_summary <- function(full,batches,cfg) {
  key <- function(x) paste(x$window_id,x$block_length,x$K,x$statistic,x$method,
    ifelse(is.na(x$p),"joint",sprintf("%.8f",x$p)),sep="|")
  groups <- split(seq_len(nrow(batches)),key(batches)); full_key <- key(full)
  rows <- lapply(seq_len(nrow(full)),function(i) {
    d <- batches[groups[[full_key[i]]],,drop=FALSE]; m <- nrow(d)
    se <- if(m>=2) sd(d$p_value)/sqrt(m) else NA_real_
    data.frame(full[i,c("window_id","block_length","K","statistic","method","p",
      "bootstrap_draws","tail_exceedances","p_value","p_value_holm_windows")],
      batches=m,min_batch_B=min(d$bootstrap_draws),max_batch_B=max(d$bootstrap_draws),
      approximate_mcse=se,mc_lower=pmax(0,full$p_value[i]-1.96*se),
      mc_upper=pmin(1,full$p_value[i]+1.96*se),
      smaller_batch_holm_rejection_fraction=mean(d$reject_holm_windows),
      few_tail_exceedances=full$tail_exceedances[i]<20L)
  })
  out <- do.call(rbind,rows)
  out$diagnostic_type <- "approximate_MC_only_not_simultaneous_not_data_confidence_interval"
  out
}

btc_paper_tables <- function(tabs,plan,cfg,dirs) {
  d <- tabs$tests
  use <- d$method %in% c("adaptive_scan","endpoint_union") |
    (d$method=="fixed_p" & d$p %in% c(1,2))
  a <- d[use & d$block_length==cfg$PRIMARY_BLOCK,]
  label <- function(z) ifelse(z$method=="fixed_p",paste0("p=",z$p),z$method)
  a$procedure <- label(a)
  counts <- aggregate(as.integer(a$reject_holm_windows),
    a[c("K","statistic","procedure")],sum)
  names(counts)[ncol(counts)] <- "rejected_windows"
  counts$total_windows <- length(unique(a$window_id))
  btc_write_csv(counts,file.path(dirs$tables,"btc_rejection_counts.csv"))
  a <- a[a$K==cfg$PRIMARY_K & a$statistic=="Energy",]
  wins <- unique(a$window_id[a$reject_holm_windows])
  a$first_open_utc <- plan$first_open_utc[match(a$window_id,plan$window_id)]
  a$last_open_utc <- plan$last_open_utc[match(a$window_id,plan$window_id)]
  btc_write_csv(a[a$window_id %in% wins,],file.path(dirs$tables,"btc_rejected_windows.csv"))
  btc_write_csv(d[d$block_length==cfg$PRIMARY_BLOCK & d$K==cfg$PRIMARY_K &
    d$statistic=="Energy" & d$method=="fixed_p",],
    file.path(dirs$tables,"paper_simultaneous_powers.csv"))
}

btc_plot_paper <- function(tabs,cfg,path) {
  tt <- tabs$tests
  primary <- tt[tt$block_length==cfg$PRIMARY_BLOCK & tt$K==cfg$PRIMARY_K &
    tt$statistic=="Energy" & tt$method=="adaptive_scan",]
  left_windows <- primary$window_id[primary$reject_holm_windows]
  extra_windows <- c("2024_W07","2025_W06")
  wins <- unique(c(left_windows,intersect(extra_windows,primary$window_id)))
  cols <- rep(c("#0072B2","#D55E00","#009E73","#8E5AA7"),length.out=length(wins))
  marks <- rep(c(16,17,15,18),length.out=length(wins))
  styles <- rep(1:4,length.out=length(wins))
  grDevices::pdf(path,width=7.5,height=4,pointsize=11,family="Helvetica",useDingbats=FALSE)
  on.exit(grDevices::dev.off(),add=TRUE)
  layout(matrix(c(1,2,3,3),2,2,byrow=TRUE),heights=c(1,.19))
  par(cex=1,mar=c(4.1,4.4,2,1),mgp=c(2.7,.65,0),las=1,tcl=-.25,
      cex.axis=.92,cex.main=1.05,cex.lab=.92)
  a <- tt[tt$block_length==cfg$PRIMARY_BLOCK & tt$K==cfg$PRIMARY_K &
    tt$statistic=="Energy" & tt$method=="fixed_p" & tt$window_id%in%left_windows,]
  plot(NA,xlim=range(cfg$P_GRID),ylim=c(0,max(5.65,1.05*a$scaled_statistic)),
    xlab="Power p",ylab="Energy / bootstrap reference mean",main="Power profiles",xaxt="n")
  axis(1,at=c(1,1.25,1.5,1.75,2))
  abline(h=1,lty=3,col="grey50")
  if(!length(left_windows)) text(mean(range(cfg$P_GRID)),2.8,"No main scan rejections")
  for(win in left_windows) {
    i <- match(win,wins); z <- a[a$window_id==win,];z <- z[order(z$p),]
    lines(z$p,z$scaled_statistic,type="b",pch=marks[i],lty=styles[i],col=cols[i],lwd=1.5,cex=.8)
  }
  z <- tt[tt$K==cfg$PRIMARY_K & tt$statistic=="Energy" &
    tt$method=="adaptive_scan" & tt$window_id%in%wins,]
  ylim <- range(c(.0035,.12,z$p_value_holm_windows))
  plot(NA,xlim=range(cfg$BLOCK_LENGTHS),ylim=ylim,log="y",xaxt="n",yaxt="n",
    xlab="Mean block length (five-minute intervals)",ylab="Holm-adjusted p-value",
    main="Block-length sensitivity")
  axis(1,at=cfg$BLOCK_LENGTHS)
  axis(2,at=c(.005,.01,.025,.05,.1),labels=c("0.005","0.01","0.025","0.05","0.1"))
  abline(h=cfg$LEVEL,lty=3,col="grey50")
  for(i in seq_along(wins)) {
    a <- z[z$window_id==wins[i],];a <- a[order(a$block_length),]
    lines(a$block_length,a$p_value_holm_windows,type="b",pch=marks[i],lty=styles[i],
      col=cols[i],lwd=1.5,cex=.8)
  }
  par(mar=rep(0,4));plot.new()
  if(length(wins)) legend("center",legend=gsub("_"," ",wins),pch=marks,lty=styles,
    col=cols,lwd=1.5,bty="n",ncol=min(4,length(wins)),cex=.92)
  invisible(wins)
}

if (!identical(getOption("btc.autorun"),FALSE)) {
  args <- commandArgs(trailingOnly=TRUE)
  if ("--quick"%in%args) CFG$QUICK <- TRUE
  for (a in args) {
    if (grepl("^--cores=",a)) CFG$CORES <- as.integer(sub("^--cores=","",a))
    if (grepl("^--B=",a)) CFG$B <- as.integer(sub("^--B=","",a))
  }
  BTC_RESULT <- btc_run(CFG,BTC_SCRIPT_PATH)
}
