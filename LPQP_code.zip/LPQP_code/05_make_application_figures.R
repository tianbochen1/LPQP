lpqp_application_dir <- function() {
  files <- Filter(Negate(is.null),lapply(sys.frames(),function(x) x$ofile))
  if(length(files)) return(dirname(normalizePath(tail(files,1)[[1]],mustWork=TRUE)))
  args <- grep("^--file=",commandArgs(FALSE),value=TRUE)
  if(length(args)) return(dirname(normalizePath(sub("^--file=","",args[1]),mustWork=TRUE)))
  getwd()
}
LPQP_APPLICATION_DIR <- lpqp_application_dir()

lpqp_plot_dk1 <- function(x,frame) {
  if(is.character(x)) x <- readRDS(x)
  dir.create(frame,recursive=TRUE,showWarnings=FALSE)
  variants <- c("raw","calendar_adjusted")
  powers <- c(1,1.25,1.5,2)
  colors <- c("#0072B2","#009E73","#CC79A7","#D55E00")
  types <- c(1,2,3,4)
  spectra <- list()
  for(v in variants) {
    ss <- lapply(x$results,function(z) z$description[[v]]$spectra)
    stopifnot(length(ss)>0,all(vapply(ss,function(z) identical(z$frequency,ss[[1]]$frequency),logical(1))))
    mean_spectrum <- Reduce("+",lapply(ss,`[[`,"smooth_shape"))/length(ss)
    spectra[[v]] <- list(frequency=ss[[1]]$frequency,spectrum=mean_spectrum)
  }
  pdf(file.path(frame,"dk1_spectra.pdf"),width=8.6,height=3.7,
      pointsize=11,family="Helvetica",useDingbats=FALSE)
  tryCatch({
    layout(matrix(c(1,2,3,3),2,2,byrow=TRUE),heights=c(1,.22))
    par(cex=1,mar=c(4.1,4.2,2.5,1.2),mgp=c(2.7,.6,0),las=1,
        cex.axis=.85,cex.lab=.9,cex.main=1)
    for(v in variants) {
      s <- spectra[[v]]
      plot(NA,xlim=c(0,.125),ylim=c(.02,150),log="y",xaxs="i",xaxt="n",yaxt="n",
        xlab="Frequency (cycles/hour)",ylab=if(v=="raw") "Mean normalized spectrum" else "",
        main=if(v=="raw") "Raw prices" else "Calendar-adjusted prices")
      lower <- c(1/192,1/26,1/13)
      upper <- c(1/144,1/22,1/11)
      rect(lower,rep(.02,3),upper,rep(150,3),border=NA,col=adjustcolor("grey60",alpha.f=.16))
      text(lower[1],95,"Weekly",cex=.8,adj=c(0,.5))
      text(c(mean(c(lower[2],upper[2])),mean(c(lower[3],upper[3]))),rep(95,2),
        c("Daily","Half-daily"),cex=.8,adj=c(.5,.5))
      axis(1,at=c(0,.025,.05,.075,.1,.125),labels=c("0","0.025","0.05","0.075","0.10","0.125"))
      axis(2,at=c(.03,.1,1,10,100),labels=c("0.03","0.1","1","10","100"))
      abline(h=1,lty=3,col="grey50")
      use <- s$frequency<=.125
      for(j in seq_along(powers)) {
        column <- match(powers[j],x$config$P_GRID)
        stopifnot(!is.na(column))
        lines(s$frequency[use],s$spectrum[use,column],col=colors[j],lty=types[j],lwd=1.3)
      }
    }
    par(mar=rep(0,4));plot.new()
    legend("center",paste0("p = ",powers),col=colors,lty=types,lwd=1.3,horiz=TRUE,bty="n",cex=.9)
  },finally=dev.off())
  bands <- x$tables$bands
  band_names <- c("weekly","daily","half_daily")
  titles <- c("Weekly (144-192 h)","Daily (22-26 h)","Half-daily (11-13 h)")
  years <- sort(unique(bands$year))
  colors <- c("#0072B2","#D55E00")
  pdf(file.path(frame,"dk1_band_mass.pdf"),width=8.6,height=5.2,
      pointsize=11,family="Helvetica",useDingbats=FALSE)
  tryCatch({
    layout(rbind(matrix(1:6,2,3,byrow=TRUE),rep(7,3)),heights=c(1,1,.22))
    par(cex=1,mar=c(3.5,3.8,3,.6),mgp=c(2.4,.6,0),las=1,cex.axis=.8,cex.lab=.9,cex.main=.9)
    for(v in variants) for(j in seq_along(band_names)) {
      d <- bands[bands$variant==v & bands$band==band_names[j],]
      limit <- ceiling(max(100*bands$mass[bands$band==band_names[j]])/5)*5
      plot(NA,xlim=c(.98,2.02),ylim=c(0,limit),xaxt="n",
        xlab=if(v=="calendar_adjusted") "Power p" else "",
        ylab=if(j==1) "Band mass (%)" else "",
        main=paste(if(v=="raw") "Raw prices" else "Calendar-adjusted prices",titles[j],sep="\n"))
      axis(1,at=c(1,1.25,1.5,1.75,2),labels=c("1","1.25","1.5","1.75","2"))
      abline(h=axTicks(2),col="grey90",lwd=.6)
      for(i in seq_along(years)) {
        by <- d[d$year==years[i],]
        for(win in unique(by$window_id)) {
          z <- by[by$window_id==win,];z <- z[order(z$p),]
          lines(z$p,100*z$mass,col=adjustcolor(colors[i],alpha.f=.25),lwd=.7)
        }
        av <- aggregate(mass~p,by,mean)
        lines(av$p,100*av$mass,type="b",col=colors[i],lty=i,pch=c(16,17)[i],lwd=1.5,cex=.7)
      }
    }
    par(mar=rep(0,4));plot.new()
    legend("center",legend=as.character(years),col=colors,lty=seq_along(years),pch=c(16,17),lwd=1.5,horiz=TRUE,bty="n",cex=.9)
  },finally=dev.off())
  average <- aggregate(mass~variant+band+p,bands,mean)
  average$mass_percent <- 100*average$mass
  write.csv(average,file.path(frame,"dk1_band_mass_mean.csv"),row.names=FALSE)
  invisible(spectra)
}

lpqp_plot_btc <- function(x,frame) {
  if(is.character(x)) x <- readRDS(x)
  dir.create(frame,recursive=TRUE,showWarnings=FALSE)
  old <- options(btc.autorun=FALSE)
  on.exit(options(old))
  env <- new.env(parent=.GlobalEnv)
  source(file.path(LPQP_APPLICATION_DIR,"BTCUSDT_LpQP_all_in_one.R"),local=env)
  env$btc_plot_paper(x$tables,x$config,file.path(frame,"btc_profiles.pdf"))
}

lpqp_application_figures <- function() {
  settings <- modifyList(list(
    DK1_RDS=file.path(LPQP_APPLICATION_DIR,"outputs","dk1","results","DK1_LpQP_results.rds"),
    BTC_RDS=file.path(LPQP_APPLICATION_DIR,"outputs","btc","results","BTCUSDT_LpQP_results.rds"),
    FIGURE_DIR=file.path(LPQP_APPLICATION_DIR,"outputs","frame")
  ),getOption("lpqp.application.figures",list()))
  count <- 0L
  if(!is.null(settings$DK1_RDS) && file.exists(settings$DK1_RDS)) {
    lpqp_plot_dk1(settings$DK1_RDS,settings$FIGURE_DIR)
    count <- count+1L
  }
  if(!is.null(settings$BTC_RDS) && file.exists(settings$BTC_RDS)) {
    lpqp_plot_btc(settings$BTC_RDS,settings$FIGURE_DIR)
    count <- count+1L
  }
  if(count==0L) stop("No application results found. Set paths with options(lpqp.application.figures=list(...)).")
  invisible(settings$FIGURE_DIR)
}

if(!identical(getOption("lpqp.application.figures.autorun"),FALSE)) lpqp_application_figures()
