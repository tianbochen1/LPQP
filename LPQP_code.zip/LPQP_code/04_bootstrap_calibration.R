CAL_CFG <- list(
  MODE="full", N=8064L, REPLICATIONS=2000L, B=1999L, CORES=8L,
  P_GRID=c(1,1.15,1.25,1.35,1.5,1.75,2), K_GRID=c(12L,72L),
  PRIMARY_K=12L, BLOCK_LENGTHS=144L, PRIMARY_BLOCK=144L,
  INNOVATIONS=c("normal","t5"), ROUND_STEPS=c(0,0.02),
  OMEGA=0.05, ARCH=0.05, GARCH=0.90, BURN_IN=5000L,
  LEVEL=0.05, DIAGNOSTIC_LEVELS=c(0.05,0.01,0.05/26),
  ROOT_TOL=1e-10, SEED=20260926L, RESUME=TRUE,
  BATCH_SIZE=16L, SAVE_SUMMARY_EVERY=128L, OUTPUT_DIR=NULL
)
cal_this_file <- function() {
  f <- Filter(Negate(is.null),lapply(sys.frames(),function(x) x$ofile))
  if(length(f)) return(normalizePath(tail(f,1)[[1]],mustWork=TRUE))
  a <- grep("^--file=",commandArgs(FALSE),value=TRUE)
  if(length(a)) return(normalizePath(sub("^--file=","",a[1]),mustWork=TRUE))
  file.path(getwd(),"04_bootstrap_calibration.R")
}
CAL_SOURCE <- cal_this_file(); CAL_BASE <- dirname(CAL_SOURCE)
source(file.path(CAL_BASE,"lpqp_support.R"),local=environment())
lpqs_source(file.path(CAL_BASE,"BTCUSDT_LpQP_all_in_one.R"),"btc.autorun",environment())

cal_config <- function(overrides=getOption("cal.config",list())) {
  cfg <- modifyList(CAL_CFG,overrides)
  stopifnot(cfg$MODE %in% c("full","pilot","smoke"))
  if(cfg$MODE=="smoke") {
    defaults <- list(N=320L,REPLICATIONS=2L,B=39L,BURN_IN=200L,BATCH_SIZE=4L)
    for(nm in names(defaults)) if(!nm %in% names(overrides)) cfg[[nm]] <- defaults[[nm]]
  }
  if(cfg$MODE=="pilot") {
    if(!"REPLICATIONS"%in%names(overrides)) cfg$REPLICATIONS <- 100L
    if(!"B"%in%names(overrides)) cfg$B <- 999L
  }
  if(is.null(cfg$OUTPUT_DIR)) cfg$OUTPUT_DIR <- file.path(CAL_BASE,"outputs",if(cfg$MODE=="full") "calibration" else paste0("calibration_",cfg$MODE))
  cfg$RUN_SCOPE <- "calibration"; cfg$CODE_VERSION <- "1.0.0"
  cfg$K_GRID <- sort(unique(as.integer(cfg$K_GRID)))
  cfg$BLOCK_LENGTHS <- sort(unique(as.integer(cfg$BLOCK_LENGTHS)))
  stopifnot(cfg$N>max(cfg$K_GRID),cfg$REPLICATIONS>=2,cfg$B>=19,cfg$CORES>=1,
    all(cfg$P_GRID>=1 & cfg$P_GRID<=2),all(c(1,2)%in%cfg$P_GRID),
    cfg$PRIMARY_K%in%cfg$K_GRID,all(cfg$BLOCK_LENGTHS>=2),
    cfg$PRIMARY_BLOCK%in%cfg$BLOCK_LENGTHS,
    cfg$OMEGA>0,cfg$ARCH>=0,cfg$GARCH>=0,cfg$ARCH+cfg$GARCH<1,
    all(cfg$ROUND_STEPS>=0),all(cfg$INNOVATIONS%in%c("normal","t5")),
    cfg$BURN_IN>=1,cfg$BATCH_SIZE>=1,cfg$SAVE_SUMMARY_EVERY>=1,
    all(cfg$DIAGNOSTIC_LEVELS>0 & cfg$DIAGNOSTIC_LEVELS<1))
  cfg
}

cal_generate <- function(cfg,innovation,round_step) {
  size <- cfg$BURN_IN+cfg$N+max(cfg$K_GRID)
  e <- if(innovation=="normal") rnorm(size) else rt(size,df=5)*sqrt(3/5)
  y <- numeric(size); v <- cfg$OMEGA/(1-cfg$ARCH-cfg$GARCH)
  y[1] <- sqrt(v)*e[1]
  for(t in 2:size) {
    v <- cfg$OMEGA+cfg$ARCH*y[t-1]^2+cfg$GARCH*v
    y[t] <- sqrt(v)*e[t]
  }
  y <- tail(y,cfg$N+max(cfg$K_GRID))

  if(round_step>0) y <- round_step*round(y/round_step)
  y
}

cal_one <- function(task,cfg) {
  tryCatch({
    if(cfg$RESUME && file.exists(task$file)) return(readRDS(task$file))
    assign(".Random.seed",task$data_seed,.GlobalEnv)
    y <- cal_generate(cfg,task$innovation,task$round_step)
    pre <- btc_prepare(y,max(cfg$K_GRID))
    fit <- btc_moments(pre,cfg$P_GRID,tol=cfg$ROOT_TOL)
    assign(".Random.seed",task$bootstrap_seed,.GlobalEnv)
    boot <- matrix(NA_real_,cfg$B,max(cfg$K_GRID)*length(cfg$P_GRID))
    for(b in seq_len(cfg$B)) boot[b,] <- as.vector(btc_moments(pre,cfg$P_GRID,
      btc_stationary_weights(pre$n,task$block_length),cfg$ROOT_TOL)$acf)
    bc <- cfg; bc$SAVE_BOOTSTRAP_STATISTICS <- FALSE
    ans <- btc_calibrate(fit$acf,boot,pre$n,bc)
    meta <- data.frame(case_id=task$case_id,innovation=task$innovation,
      round_step=task$round_step,replication=task$replication,block_length=task$block_length,n=cfg$N)
    core <- tail(y,cfg$N); med <- median(core)
    result <- list(ok=TRUE,tests=cbind(meta,ans$tests),
      diagnostics=cbind(meta,median=med,ties_at_median=sum(core==med),
        zero_fraction=mean(core==0),tie_fraction=mean(core==med),
        ordinary_variance=var(core),max_abs_return=max(abs(core))))
    lpqs_save(result,task$file)
    result
  },error=function(e) list(ok=FALSE,case_id=task$case_id,replication=task$replication,
      block_length=task$block_length,message=conditionMessage(e)))
}

cal_summarize <- function(raw,cfg) {
  key <- paste(raw$case_id,raw$block_length,raw$K,raw$statistic,raw$method,
    ifelse(is.na(raw$p),"joint",sprintf("%.8f",raw$p)),sep="|")
  rows <- list()
  for(ix in split(seq_len(nrow(raw)),key)) {
    a <- raw[ix,,drop=FALSE]
    if(anyDuplicated(a$replication)) stop("Duplicate Monte Carlo replication")
    for(level in cfg$DIAGNOSTIC_LEVELS) {
      k <- sum(a$p_value<=level); nn <- nrow(a); ci <- lpqs_wilson(k,nn)
      rows[[length(rows)+1L]] <- data.frame(a[1,c("case_id","innovation","round_step",
        "block_length","n","K","statistic","method","p")],
        nominal_level=level,attainable_p_threshold=floor((cfg$B+1)*level)/(cfg$B+1),
        replications=nn,rejections=k,rejection_rate=k/nn,
        mcse=sqrt((k/nn)*(1-k/nn)/nn),lower95=ci[1],upper95=ci[2],
        expected_rejections_at_nominal=nn*level,
        rare_tail_low_precision=nn*level<20,
        binomial_p_upper=pbinom(k-1,nn,level,lower.tail=FALSE))
    }
  }
  out <- do.call(rbind,rows); rownames(out)<-NULL
  out$diagnostic_p_holm <- NA_real_

  for(level in cfg$DIAGNOSTIC_LEVELS) {
    ix <- which(out$nominal_level==level)
    out$diagnostic_p_holm[ix] <- p.adjust(out$binomial_p_upper[ix],"holm")
  }
  out$size_flag <- out$nominal_level==cfg$LEVEL & out$diagnostic_p_holm<.05
  out
}

cal_run <- function(cfg=cal_config()) {
  old <- lpqs_rng_save(); on.exit(lpqs_rng_restore(old),add=TRUE)
  files <- file.path(CAL_BASE,c("04_bootstrap_calibration.R","BTCUSDT_LpQP_all_in_one.R","lpqp_support.R"))
  out <- lpqs_prepare(cfg,files)
  cases <- expand.grid(innovation=cfg$INNOVATIONS,round_step=cfg$ROUND_STEPS,stringsAsFactors=FALSE)
  cases$case_id <- seq_len(nrow(cases)); lpqs_csv(cases,file.path(out,"design.csv"))
  streams <- lpqs_streams(nrow(cases)*cfg$REPLICATIONS,cfg$SEED)
  tasks <- list(); pos <- 0L
  for(i in seq_len(nrow(cases))) for(r in seq_len(cfg$REPLICATIONS)) {
    pos <- pos+1L; bs <- parallel::nextRNGSubStream(streams[[pos]])
    for(L in cfg$BLOCK_LENGTHS) {
      tasks[[length(tasks)+1L]] <- list(case_id=i,innovation=cases$innovation[i],
        round_step=cases$round_step[i],replication=r,block_length=L,
        data_seed=streams[[pos]],bootstrap_seed=bs,
        file=file.path(out,"checkpoints",sprintf("case_%02d_rep_%05d_L%d.rds",i,r,L)))
      bs <- parallel::nextRNGSubStream(bs)
    }
  }
  cl <- lpqs_cluster(cfg$CORES,environment(cal_run),out)
  on.exit(if(!is.null(cl)) parallel::stopCluster(cl),add=TRUE)
  result <- vector("list",length(tasks)); groups <- split(seq_along(tasks),
    ceiling(seq_along(tasks)/cfg$BATCH_SIZE)); tic <- proc.time()[3]
  for(g in seq_along(groups)) {
    ix <- groups[[g]]
    result[ix] <- if(is.null(cl)) lapply(tasks[ix],cal_one,cfg=cfg) else
      parallel::parLapplyLB(cl,tasks[ix],cal_one,cfg=cfg)
    bad <- Filter(function(z) !isTRUE(z$ok),result[ix])
    if(length(bad)) {
      lpqs_csv(do.call(rbind,lapply(bad,as.data.frame)),file.path(out,"logs","errors.csv"))
      stop("Calibration jobs failed; inspect logs/errors.csv. Completed replications are retained.")
    }
    message(sprintf("Calibration: %d/%d jobs; %.1f minutes",max(ix),length(tasks),(proc.time()[3]-tic)/60))
    if(max(ix)%%cfg$SAVE_SUMMARY_EVERY==0L || g==length(groups)) {
      raw <- do.call(rbind,lapply(result[seq_len(max(ix))],`[[`,"tests"))
      lpqs_csv(cal_summarize(raw,cfg),file.path(out,"calibration_summary.csv"))
    }
  }
  raw <- do.call(rbind,lapply(result,`[[`,"tests"))
  diagnostics <- do.call(rbind,lapply(result,`[[`,"diagnostics"))
  summary <- cal_summarize(raw,cfg)
  lpqs_save(list(config=cfg,design=cases,raw=raw,summary=summary,diagnostics=diagnostics),
    file.path(out,"calibration_results.rds"),compress=TRUE)
  lpqs_csv(summary,file.path(out,"calibration_summary.csv"))
  lpqs_csv(diagnostics,file.path(out,"ties_and_scale.csv"))
  lpqs_csv(summary[summary$size_flag,],file.path(out,"size_flags.csv"))
  print(summary[summary$nominal_level==cfg$LEVEL & summary$K==cfg$PRIMARY_K &
    summary$method=="adaptive_scan",],row.names=FALSE)
  invisible(list(config=cfg,summary=summary,raw=raw,output_dir=out))
}

if(!identical(getOption("cal.autorun"),FALSE)) {
  CAL_RESULT <- cal_run()
}
